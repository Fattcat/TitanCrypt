STARÉ VERZIE – NEPOUŽÍVAŤ NA NOVÉ ŠIFROVANIE

TitanCrypt_OLD_XOR.py / .html používajú XOR s opakovaným kľúčom a pri obrázkoch iba
premiešanie pixelov (predvídateľný PRNG). Dá sa to prelomiť (known-plaintext, histogram).
Navyše .py a .html verzia používajú RÔZNE generátory náhodných čísel, takže si
navzájom nikdy neotvoria súbory. Tento rozpor bol jedným zo zdrojov "nefunguje kamarátovi".
Ponechané len na referenciu. Nová appka tieto súbory zámerne nedešifruje.
