"""
End-to-end test celej appky (Flask test client, bez GUI).
Spusti:  python tests/test_app.py
"""
import io
import os
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
APPDIR = os.path.join(HERE, "..", "Win11-App")
KEY = "SIGQQ-O1234-5CGOW-ABCDE-12345"

# každý test beží s vlastným dátovým priečinkom, nech nešpiní reálnu históriu
_tmp = tempfile.mkdtemp()
os.environ["LOCALAPPDATA"] = _tmp
sys.argv.append("--no-gui")
sys.path.insert(0, APPDIR)

import TitanCryptSouceCode as appmod  # noqa: E402
from PIL import Image  # noqa: E402

appmod.app.config["TESTING"] = True
C = appmod.app.test_client()
H = {"Origin": "http://127.0.0.1:5000"}


def png(w=64, h=48):
    import random
    r = random.Random(7)
    im = Image.new("RGB", (w, h))
    im.putdata([(r.randrange(256), r.randrange(256), r.randrange(256)) for _ in range(w * h)])
    b = io.BytesIO(); im.save(b, "PNG")
    return b.getvalue()


def wait_task(tid, timeout=20):
    t0 = time.time()
    while time.time() - t0 < timeout:
        s = C.get(f"/status/{tid}").get_json()
        if s["done"] or s["error"]:
            return s
        time.sleep(0.1)
    raise AssertionError("task timeout")


def encrypt_http(data, filename, use_keyfile=False, key=KEY):
    r = C.post("/start_encrypt", headers=H, content_type="multipart/form-data",
               data={"image": (io.BytesIO(data), filename), "key": key, "speed_mode": "high",
                     "use_keyfile": "1" if use_keyfile else "0"})
    assert r.status_code == 200, r.data
    s = wait_task(r.get_json()["task_id"])
    assert s["done"], s
    blob = C.get("/download_encrypted_image").data
    kf = C.get("/download_decryption_key")
    return blob, (kf.data if kf.status_code == 200 else None)


def decrypt_http(blob, keyfile, key=KEY, name="encrypted.tcrypt"):
    d = {"image_file": (io.BytesIO(blob), name), "key": key, "speed_mode": "high"}
    if keyfile is not None:
        d["key_file"] = (io.BytesIO(keyfile), "decryption_key.key")
    r = C.post("/start_decrypt", headers=H, content_type="multipart/form-data", data=d)
    assert r.status_code == 200, r.data
    return wait_task(r.get_json()["task_id"])


def test_pages_render_and_headers():
    r = C.get("/")
    assert r.status_code == 200
    html = r.get_data(as_text=True)
    assert "StegoCrypt" in html and "ImgCrypt" in html and "TextCrypt" in html
    assert r.headers["X-Content-Type-Options"] == "nosniff"
    assert "frame-ancestors 'none'" in r.headers["Content-Security-Policy"]
    for q in ("encrypt_success", "decrypt_success", "stego_hide_success", "stego_extract_success"):
        assert C.get(f"/?task={q}").status_code == 200


def test_guards():
    assert C.get("/", headers={"Host": "evil.example.com"}).status_code == 403       # DNS rebinding
    r = C.post("/start_encrypt", headers={"Origin": "http://evil.example.com"})
    assert r.status_code == 403                                                      # CSRF
    assert C.post("/history/delete/TextCrypt/Encrypted_x", headers={"Origin": "https://evil.com"}).status_code == 403
    assert C.post("/history/delete/..%2F..%2Fx", headers=H).status_code in (400, 404)  # path traversal


def test_image_single_file_flow_and_original_bytes_restored():
    data = png()
    blob, kf = encrypt_http(data, "moja foto (1).png")
    assert kf is None and blob[:4] == b"TCRY"
    s = decrypt_http(blob, None)
    assert s["done"], s
    assert C.get("/download_decrypted").data == data              # bajt-po-bajte originál (bez re-enkódovania)
    r = C.get("/download_decrypted")
    assert "moja_foto__1_.png" in r.headers["Content-Disposition"]
    assert C.get("/preview_decrypted").mimetype == "image/png"
    assert "Dešifrovaný výsledok" in C.get("/?task=decrypt_success").get_data(as_text=True)


def test_image_with_keyfile_flow_and_errors_are_specific():
    data = png()
    blob, kf = encrypt_http(data, "a.png", use_keyfile=True)
    assert kf is not None and len(kf) == 41
    assert decrypt_http(blob, kf)["done"]
    assert "KEYFILE" in decrypt_http(blob, None)["error"].upper() or ".key" in decrypt_http(blob, None)["error"]
    assert "Nesprávny kľúč" in decrypt_http(blob, kf, key="AAAAA-AAAAA-AAAAA-AAAAA-AAAAA")["error"]
    mangled = decrypt_http(blob, kf + b"\r\n")["error"]
    assert "41" in mangled and "prenose" in mangled              # presne scenár "kamarát dostal pozmenený .key"
    bad = bytearray(blob); bad[50] ^= 4
    assert "poškodený" in decrypt_http(bytes(bad), kf)["error"]


def test_wrong_key_format_message():
    r = C.post("/start_encrypt", headers=H, content_type="multipart/form-data",
               data={"image": (io.BytesIO(b"x"), "a.bin"), "key": "KRATKY", "speed_mode": "high"})
    s = wait_task(r.get_json()["task_id"])
    assert "25 znakov" in s["error"]


def test_text_flow_and_error_alert_is_xss_safe():
    r = C.post("/text_encrypt", headers=H, data={"key": KEY, "plain_text": "Ahoj žltý kôň"})
    html = r.get_data(as_text=True)
    enc = html.split('id="encrypted-text-display" readonly>')[1].split("</textarea>")[0]
    assert enc.startswith("TC2:")
    r = C.post("/text_decrypt", headers=H, data={"key": KEY, "encrypted_text": enc})
    assert "Ahoj žltý kôň" in r.get_data(as_text=True)
    r = C.post("/text_decrypt", headers=H, data={"key": KEY, "encrypted_text": "TC2:" + "A" * 80})
    assert "<script>alert(" in r.get_data(as_text=True)
    r = C.post("/text_encrypt", headers=H, data={"key": KEY, "plain_text": "<script>x</script>"})
    assert "&lt;script&gt;" in r.get_data(as_text=True) or "TC2:" in r.get_data(as_text=True)


def test_history_has_no_plaintext_or_password():
    C.post("/text_encrypt", headers=H, data={"key": KEY, "plain_text": "SUPERTAJNY-TEXT-123"})
    blob = b""
    root = os.path.join(_tmp, "TitanCrypt")
    for dp, _, fs in os.walk(root):
        for f in fs:
            blob += open(os.path.join(dp, f), "rb").read()
    assert b"SUPERTAJNY-TEXT-123" not in blob
    assert KEY.replace("-", "").encode() not in blob
    assert C.get("/history/list").get_json()["folders"]


def test_stego_http_flow():
    cover = png(120, 120)
    r = C.post("/stego_hide", headers=H, content_type="multipart/form-data",
               data={"cover": (io.BytesIO(cover), "c.png"), "key": KEY, "secret_text": "vzkaz 🐎",
                     "use_keyfile": "1"})
    assert r.get_json().get("ok"), r.get_json()
    stego = C.get("/download_stego").data
    skey = C.get("/download_stego_key").data
    r = C.post("/stego_extract", headers=H, content_type="multipart/form-data",
               data={"stego_image": (io.BytesIO(stego), "s.png"), "key": KEY, "key_file": (io.BytesIO(skey), "k.key")})
    assert r.get_json().get("ok"), r.get_json()
    assert "vzkaz 🐎" in C.get("/?task=stego_extract_success").get_data(as_text=True)
    r = C.post("/stego_extract", headers=H, content_type="multipart/form-data",
               data={"stego_image": (io.BytesIO(stego), "s.png"), "key": KEY})
    assert ".key" in r.get_json()["error"]
    r = C.post("/stego_hide", headers=H, content_type="multipart/form-data",
               data={"cover": (io.BytesIO(png(8, 8)), "c.png"), "key": KEY, "secret_text": "x" * 500})
    assert "primalý" in r.get_json()["error"]


def test_FRIEND_PC_separate_process_and_other_data_dir():
    """Simulácia kamaráta: súbory zašifrované tu, otvorené v ÚPLNE inom procese s inou zložkou dát."""
    data = png(50, 50)
    blob, kf = encrypt_http(data, "p.png", use_keyfile=True)
    txt = C.post("/text_encrypt", headers=H, data={"key": KEY, "plain_text": "pre kamarata"}).get_data(as_text=True)
    enc = txt.split('id="encrypt-ed' if False else 'id="encrypted-text-display" readonly>')[1].split("</textarea>")[0]
    d = tempfile.mkdtemp()
    open(os.path.join(d, "f.tcrypt"), "wb").write(blob)
    open(os.path.join(d, "f.key"), "wb").write(kf)
    code = f"""
import sys, os
sys.path.insert(0, {APPDIR!r})
import titancrypt_core as tc
b = open({os.path.join(d,'f.tcrypt')!r},'rb').read(); k = open({os.path.join(d,'f.key')!r},'rb').read()
assert tc.decrypt(b, {KEY!r}, keyfile=k).data[:8] == b'\\x89PNG\\r\\n\\x1a\\n'
assert tc.text_decrypt({enc!r}, {KEY!r}) == 'pre kamarata'
print('FRIEND_OK')
"""
    env = dict(os.environ, LOCALAPPDATA=tempfile.mkdtemp(), PYTHONHASHSEED="123")
    out = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, env=env, cwd=d)
    assert "FRIEND_OK" in out.stdout, out.stderr


if __name__ == "__main__":
    import traceback
    fails = 0
    for n, f in sorted(globals().items()):
        if n.startswith("test_") and callable(f):
            try:
                f(); print("OK  ", n)
            except Exception:
                fails += 1; print("FAIL", n); traceback.print_exc()
    sys.exit(1 if fails else 0)
