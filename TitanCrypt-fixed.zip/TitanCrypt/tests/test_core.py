"""Spusti:  python -m pytest -q tests     (alebo)   python tests/test_core.py"""
import io
import os
import secrets
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "Win11-App"))

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
from PIL import Image

import titancrypt_core as tc

KEY = "SIGQQ-O1234-5CGOW-ABCDE-12345"
KEY2 = "ZZZZZ-ZZZZZ-ZZZZZ-ZZZZZ-ZZZZZ"


def raises(code, fn, *a, **k):
    try:
        fn(*a, **k)
    except tc.TitanError as e:
        assert e.code == code, f"očakávaný {code}, dostal {e.code}: {e.message}"
        return e
    raise AssertionError(f"nevyhodilo {code}")


def png(w=64, h=64, mode="RGB", seed=1):
    import random
    r = random.Random(seed)
    img = Image.new(mode, (w, h))
    img.putdata([tuple(r.randrange(256) for _ in range(len(mode))) for _ in range(w * h)])
    b = io.BytesIO()
    img.save(b, "PNG")
    return b.getvalue()


# ---------------- TC2 súbory ----------------
def test_roundtrip_file_and_name():
    data = secrets.token_bytes(5000)
    blob = tc.encrypt(data, KEY, name="foto.jpg")
    o = tc.decrypt(blob, KEY)
    assert o.data == data and o.name == "foto.jpg" and o.format_version == 2


def test_key_normalization_same_on_both_pcs():
    blob = tc.encrypt(b"x", KEY)
    assert tc.decrypt(blob, KEY.lower().replace("-", " ")).data == b"x"


def test_wrong_password_vs_corrupted_are_distinguished():
    blob = tc.encrypt(b"tajne", KEY)
    raises("WRONG_PASSWORD", tc.decrypt, blob, KEY2)
    bad = bytearray(blob)
    bad[60] ^= 1
    raises("CORRUPTED", tc.decrypt, bytes(bad), KEY)          # nie "zlé heslo"!
    raises("CORRUPTED", tc.decrypt, blob + b"\n", KEY)        # pridaný koniec riadku pri prenose
    raises("TRUNCATED", tc.decrypt, blob[:30], KEY)


def test_header_tamper_detected_even_if_crc_fixed():
    import struct, zlib
    blob = bytearray(tc.encrypt(b"tajne", KEY))
    blob[5] ^= 0x01                      # flag keyfile
    body = bytes(blob[:-4])
    fixed = body + struct.pack(">I", zlib.crc32(body) & 0xFFFFFFFF)
    try:
        tc.decrypt(fixed, KEY)
    except tc.TitanError as e:
        assert e.code in ("KEYFILE_REQUIRED", "WRONG_PASSWORD")
    else:
        raise AssertionError("zmenená hlavička prešla")


def test_unique_salt_nonce_each_time():
    a, b = tc.encrypt(b"x", KEY), tc.encrypt(b"x", KEY)
    assert a[10:38] != b[10:38] and a != b


def test_version_and_kdf_guard():
    import struct, zlib
    blob = bytearray(tc.encrypt(b"x", KEY))
    blob[4] = 9
    body = bytes(blob[:-4])
    raises("UNSUPPORTED_VERSION", tc.decrypt, body + struct.pack(">I", zlib.crc32(body)), KEY)
    blob[4] = 2
    blob[7] = 30                         # N = 2^30 => DoS pokus
    body = bytes(blob[:-4])
    raises("KDF_PARAMS", tc.decrypt, body + struct.pack(">I", zlib.crc32(body)), KEY)


def test_keyfile_two_factor_and_transport_damage():
    kf = tc.make_keyfile()
    blob = tc.encrypt(b"tajne", KEY, keyfile=kf)
    assert tc.decrypt(blob, KEY, keyfile=kf).data == b"tajne"
    raises("KEYFILE_REQUIRED", tc.decrypt, blob, KEY)
    raises("WRONG_PASSWORD", tc.decrypt, blob, KEY, keyfile=tc.make_keyfile())
    raises("KEYFILE_INVALID", tc.decrypt, blob, KEY, keyfile=kf + b"\r\n")   # chat pridal CRLF
    raises("KEYFILE_INVALID", tc.decrypt, blob, KEY, keyfile=kf[:-1])
    bad = bytearray(kf); bad[10] ^= 1
    raises("KEYFILE_CORRUPT", tc.decrypt, blob, KEY, keyfile=bytes(bad))


# ---------------- Text ----------------
def test_text_roundtrip_unicode_and_chat_mangling():
    t = "Ahoj svet — žltý kôň 🐎 úpäť"
    s = tc.text_encrypt(t, KEY)
    assert s.startswith("TC2:") and tc.text_decrypt(s, KEY) == t
    mangled = "\n".join(s[i:i + 40] for i in range(0, len(s), 40))     # zalomenie riadkov
    assert tc.text_decrypt(f'  "{mangled}"  \u200b', KEY) == t
    raises("WRONG_PASSWORD", tc.text_decrypt, s, KEY2)
    raises("CORRUPTED", tc.text_decrypt, s[:-6], KEY)                   # skrátené pri kopírovaní


# ---------------- Spätná kompatibilita v1 (presne pôvodný kód z Win11 verzie) ----------------
def _v1_key(pw, salt):
    return Scrypt(salt=salt, length=32, n=2 ** 14, r=8, p=1).derive(pw.encode())


def _v1_image(data, pw):
    salt, nonce = secrets.token_bytes(16), secrets.token_bytes(12)
    return nonce + AESGCM(_v1_key(pw, salt)).encrypt(nonce, data, None), salt


def test_legacy_v1_files_still_decrypt():
    data = png()
    blob, keyfile = _v1_image(data, tc.normalize_key(KEY))
    assert tc.decrypt(blob, KEY, keyfile=keyfile).data == data


def test_legacy_v1_salt_error_is_now_explained():
    blob, salt = _v1_image(b"abc" * 10, tc.normalize_key(KEY))
    e = raises("BAD_SALT", tc.decrypt, blob, KEY, keyfile=salt + b"\n")
    assert "17" in e.message and "16" in e.message
    e = raises("BAD_SALT", tc.decrypt, blob, KEY, keyfile=tc.make_keyfile())
    assert "NOVEJ" in e.message
    raises("BAD_SALT", tc.decrypt, blob, KEY, keyfile=salt[:10])
    raises("LEGACY_NEEDS_KEY", tc.decrypt, blob, KEY)


def test_legacy_v1_text_hex():
    salt, nonce = secrets.token_bytes(16), secrets.token_bytes(12)
    ct = AESGCM(_v1_key(tc.normalize_key(KEY), salt)).encrypt(nonce, "ahoj".encode(), None)
    assert tc.text_decrypt((salt + nonce + ct).hex(), KEY) == "ahoj"


# ---------------- Stego ----------------
def test_feistel_is_bijective_and_deterministic():
    pos = tc._feistel_positions(5000, 5000, b"k" * 32)
    assert len(set(pos.tolist())) == 5000 and pos.min() >= 0 and pos.max() < 5000
    # pevný testovací vektor: rovnaký výstup na každej platforme/verzii NumPy
    assert tc._feistel_positions(5, 1000, b"k" * 32).tolist() == EXPECTED_FEISTEL


def test_stego_roundtrip_text_file_and_keyfile():
    cover = png(96, 96)
    out = tc.stego_hide(cover, "tajný vzkaz žščť".encode(), KEY, kind=tc.KIND_TEXT)
    o = tc.stego_extract(out, KEY)
    assert o.kind == tc.KIND_TEXT and o.text == "tajný vzkaz žščť"
    secret = secrets.token_bytes(1500)
    kf = tc.make_keyfile()
    out = tc.stego_hide(cover, secret, KEY, name="a.bin", keyfile=kf)
    assert tc.stego_extract(out, KEY, keyfile=kf).data == secret
    raises("KEYFILE_REQUIRED", tc.stego_extract, out, KEY)


def test_stego_wrong_key_and_clean_image():
    cover = png(64, 64)
    out = tc.stego_hide(cover, b"hello", KEY)
    raises("WRONG_PASSWORD_OR_CORRUPT", tc.stego_extract, out, KEY2)
    raises("NO_STEGO", tc.stego_extract, cover, KEY)


def test_stego_survives_png_resave_but_not_jpeg():
    cover = png(80, 80)
    out = tc.stego_hide(cover, b"hello", KEY)
    b = io.BytesIO(); Image.open(io.BytesIO(out)).save(b, "PNG", optimize=True)     # bezstratové
    assert tc.stego_extract(b.getvalue(), KEY).data == b"hello"
    j = io.BytesIO(); Image.open(io.BytesIO(out)).convert("RGB").save(j, "JPEG", quality=92)
    e = None
    try:
        tc.stego_extract(j.getvalue(), KEY)
    except tc.TitanError as ex:
        e = ex
    assert e is not None and e.code in ("NO_STEGO", "WRONG_PASSWORD_OR_CORRUPT", "CORRUPTED")


def test_stego_capacity_and_alpha_preserved():
    cover = png(20, 20)
    cap = tc.stego_capacity_bytes(20, 20)
    raises("NO_CAPACITY", tc.stego_hide, cover, b"x" * (cap + 1), KEY)
    rgba = png(50, 50, "RGBA")
    out = tc.stego_hide(rgba, b"abc", KEY)
    im = Image.open(io.BytesIO(out))
    assert im.mode == "RGBA"
    assert list(im.getchannel("A").getdata()) == list(Image.open(io.BytesIO(rgba)).getchannel("A").getdata())
    assert tc.stego_extract(out, KEY).data == b"abc"


def test_stego_only_lsb_changed():
    cover = png(64, 64)
    out = tc.stego_hide(cover, b"hello world", KEY)
    a = list(Image.open(io.BytesIO(cover)).convert("RGB").tobytes())
    b = list(Image.open(io.BytesIO(out)).convert("RGB").tobytes())
    assert all(abs(x - y) <= 1 for x, y in zip(a, b))


EXPECTED_FEISTEL = [735, 779, 181, 214, 6]  # zamknutý vektor (regresný test: pozície stega sa nesmú nikdy zmeniť)

if __name__ == "__main__":
    import traceback
    if EXPECTED_FEISTEL is None:
        print("FEISTEL vektor:", tc._feistel_positions(5, 1000, b"k" * 32).tolist())
    fails = 0
    for n, f in sorted(globals().items()):
        if n.startswith("test_") and callable(f):
            try:
                f(); print("OK  ", n)
            except Exception:
                fails += 1; print("FAIL", n); traceback.print_exc()
    sys.exit(1 if fails else 0)
