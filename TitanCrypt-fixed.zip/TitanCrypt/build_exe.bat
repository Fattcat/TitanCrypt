@echo off
rem Build TitanCrypt.exe (Windows, Python 3.10+)
cd /d "%~dp0Win11-App"
python -m pip install -r ..\requirements.txt pyinstaller || goto :err
python ..\tests\test_core.py || goto :err
python ..\tests\test_app.py  || goto :err
pyinstaller --noconfirm --clean --onefile --windowed --name TitanCrypt ^
  --icon static\TitanCryptLogo2.ico --add-data "static;static" TitanCryptSouceCode.py || goto :err
echo.
echo Hotovo: %cd%\dist\TitanCrypt.exe
echo SHA-256 (posli kamaratovi, nech si over, ze ma rovnaky subor):
certutil -hashfile dist\TitanCrypt.exe SHA256
pause
exit /b 0
:err
echo CHYBA - build zlyhal.
pause
exit /b 1
