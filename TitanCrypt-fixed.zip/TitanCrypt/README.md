# TitanCrypt 2.0

Šifrovanie/dešifrovanie textu a súborov (obrázkov) + steganografia (StegoCrypt), lokálna appka (Flask + Tkinter).

> Veľké .exe sa na GitHub nahrať nedá (limit 25 MB) – zostav si ho cez `build_exe.bat`
> (alebo pôvodný odkaz v `Win11-App/app.txt`).

## Čo sa opravilo oproti predchádzajúcej verzii

**Hlavný problém ("zlý salt" u kamaráta)** – predchádzajúci formát nemal hlavičku ani verziu:
`.key` bol holých 16 B (salt) a "zašifrovaný PNG" holé bajty s príponou `.png`. Každá odlišná zostava
.exe alebo zmena `.key` pri prenose (chat/e-mail pridá koniec riadku, skráti súbor) skončila nezrozumiteľnou
chybou a nedalo sa rozlíšiť "zlé heslo" / "poškodený súbor" / "iná verzia".

Nový formát **TC2** (`*.tcrypt`, špecifikácia v hlavičke `Win11-App/titancrypt_core.py`):
- salt, nonce aj parametre KDF sú **priamo v súbore** → nič sa nemôže "rozísť" medzi dvoma počítačmi,
- magic + verzia + CRC32 → appka povie presne: *poškodené pri prenose* ≠ *zlé heslo* ≠ *iná verzia* ≠ *chýba .key*,
- hlavička je autentifikovaná (AES-256-GCM AAD) – nedá sa potichu zmeniť,
- `.key` je **voliteľný** 2. faktor (41 B, magic + CRC); bez zaškrtnutia posielaš jediný súbor,
- súbor sa po dešifrovaní vráti **bajt po bajte aj s pôvodným názvom** (predtým sa prekódoval na PNG),
- text má tvar `TC2:...` (base64) a toleruje zalomenie riadkov, medzery, úvodzovky z chatov,
- staré súbory z predchádzajúcej AES-GCM verzie (v1) sa **stále dajú otvoriť**,
- limity na KDF parametre (súbor s podvrhnutým N=2^30 nezhodí PC).

**Ďalšie opravy v appke**
- História **už neukladá heslo ani pôvodný text/obrázok v čistom texte** (predtým `key.txt`, `OriginalText.txt`
  a originál obrázka v `C:\TitanCrypt\...`). Ukladá sa len zašifrovaný výstup, v `%LOCALAPPDATA%\TitanCrypt`.
  **Zmaž si starý `C:\TitanCrypt\TextCrypt` a `C:\TitanCrypt\ImgCrypt`** – obsahujú heslá a originály.
- Tlačidlo "Zastaviť server" naozaj zastaví server (POST `/shutdown` od Werkzeug 2.1 nefunguje; port ostával obsadený).
- Pád pri štarte, ak chýba ikona (`"..." + Exception` → `TypeError`). Ikona/logo sú teraz súčasťou .exe.
- Žiadne sťahovanie súborov z GitHubu pri štarte.
- Ochrana proti DNS-rebindingu (kontrola `Host`), CSRF na všetky POST, CSP a ďalšie hlavičky.
- Chybové hlásenie kľúča sa pri textových poliach prepínalo na nesprávny prvok.
- `.py` a `.html` verzia (XOR) sú v `legacy/` – navzájom nekompatibilné a prelomiteľné, nepoužívať.

**StegoCrypt (nové)** – v zdrojákoch nebolo, napísané nanovo: AES-256-GCM obsah sa ukryje do LSB bitov RGB
kanálov, hlavička v prvých 328 bitoch, zvyšok rozptýlený kľúčom riadenou permutáciou (Feistel, len celočíselná
aritmetika → rovnaký výsledok na každom PC). Alfa kanál sa zachová, výstup je vždy PNG.

## Zmeny v 2.0.1
- Tlačidlo „Stiahnuť“ už neprekrýva malé obrázky (je pod obrázkom + odkaz „Otvoriť v plnej veľkosti“).
- Po šifrovaní/dešifrovaní/stego sa stránka posunie na výsledok (nie navrch).
- Kompaktná hlavička: logo, nadpis hneď vpravo, „História“ v tom istom riadku.
- Po zašifrovaní appka sama overí, že sa súbor dá dešifrovať, a zobrazí **odtlačok** (veľkosť + SHA-256).
  Ak kamarátovi dešifrovanie zlyhá, jeho chyba obsahuje odtlačok prijatého súboru – porovnajte ich a hneď viete,
  či sa súbor pri prenose zmenil, alebo nahral zlý súbor.

## Dôležité obmedzenia (úprimne)

- Stego **prežije len bezstratový prenos**. Messenger/Instagram/WhatsApp ako "fotka", zmenšenie alebo JPEG
  ukryté dáta zničia. Posielať ako **súbor/dokument** alebo v ZIP-e.
- Stego z tvojho starého .exe tento kód **neotvorí** (zdroják k nemu som nemal).
- LSB stego sa dá odhaliť steganalýzou pri veľkom zaplnení obrázka; čím menší obsah voči kapacite, tým lepšie.
  Dôvernosť zaručuje AES-GCM, nie ukrytie.
- Kľúč má 25 znakov A–Z/0–9 (~129 bitov) – bezpečný, ak ho generuje 🎲 a nie človek.
- Obaja musia mať verziu appky, ktorá pozná TC2. Starý .exe súbory z TC2 neotvorí (nový otvorí aj staré v1).
- Appka je jednopoužívateľská (stav výsledkov je v pamäti procesu), počúva len na 127.0.0.1.

## Použitie

```
pip install -r requirements.txt
python Win11-App/TitanCryptSouceCode.py            # GUI (otvorí prehliadač)
python Win11-App/TitanCryptSouceCode.py --no-gui   # len server
python tests/test_core.py && python tests/test_app.py
```
Windows .exe: `build_exe.bat` (na konci vypíše SHA-256 – pošli ho kamarátovi, nech si overí, že má rovnaký súbor).

## Keď niečo nejde (diagnostika bez hesla)

```
python Win11-App/tc_inspect.py subor.tcrypt subor.key
```
Povie, či je `.key` 41 B (TC2) / 16 B (starý), alebo či ho prenos zmenil, a aký formát má šifrovaný súbor.
