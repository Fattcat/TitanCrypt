"""
TitanCrypt core v2 — čisté jadro bez Flask/Tkinter (dá sa testovať samostatne).

PREČO TOTO VZNIKLO (pôvodný problém "zlý salt" u kamaráta):
  Pôvodný formát nemal ŽIADNU hlavičku ani verziu. .key súbor bol "holý" salt
  (16 B) a šifrovaný obrázok "holé" bajty s príponou .png. Akákoľvek odlišnosť
  medzi zostavami (.exe), alebo zmena .key pri prenose (chat/e-mail/textový
  režim) viedla k nezrozumiteľnej chybe a nedalo sa rozlíšiť "zlé heslo" od
  "poškodený súbor" od "iná verzia appky".

NOVÝ FORMÁT TC2 (samo-popisný kontajner, jeden súbor *.tcrypt):
  offset  dĺžka  obsah
  0       4      magic  b"TCRY"
  4       1      verzia formátu (2)
  5       1      flags  (bit0 = potrebný aj .key súbor)
  6       1      KDF id (1 = scrypt)
  7       1      log2(N)
  8       1      r
  9       1      p
  10      16     salt (náhodný, UNIKÁTNY pre každý súbor, je priamo v súbore)
  26      12     nonce (AES-GCM)
  38      n      ciphertext + GCM tag   (celá hlavička je AAD => autentifikovaná)
  38+n    4      CRC32 celého súboru pred ním (rozlíši "poškodené pri prenose"
                 od "zlé heslo")
  Parametre KDF sú v hlavičke => budúce zmeny sa nikdy nerozbijú so starými súbormi.

Kľúčový súbor (voliteľný 2. faktor), 41 B:  b"TCKF" | ver(1) | secret(32) | crc32(4)

Stego (TCSG v1): dáta sa ukryjú do LSB bitov RGB kanálov PNG. Hlavička (salt, nonce,
dĺžka) je v prvých 328 LSB, samotný šifrovaný obsah je rozptýlený po obrázku podľa
kľúčom riadenej pseudonáhodnej permutácie (Feistel; len celočíselná aritmetika =>
rovnaký výsledok na ľubovoľnej verzii Pythonu/NumPy/OS).
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import io
import re
import secrets
import struct
import zlib
from dataclasses import dataclass
from typing import Optional, Tuple

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDFExpand
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

FORMAT_NAME = "TC2"
APP_FORMAT_VERSION = 2

MAGIC = b"TCRY"
KEYFILE_MAGIC = b"TCKF"
STEGO_MAGIC = b"TCSG"

FLAG_KEYFILE = 0x01

KDF_SCRYPT = 1
DEFAULT_LOG2N = 15          # 32 MiB RAM, ~0.1 s
DEFAULT_R = 8
DEFAULT_P = 1
MAX_LOG2N = 18              # ochrana proti DoS (súbor s vymysleným N=2^30)
MAX_R = 16
MAX_P = 4

SALT_LEN = 16
NONCE_LEN = 12
KEYFILE_SECRET_LEN = 32

HEADER_LEN = 4 + 1 + 1 + 1 + 1 + 1 + 1 + SALT_LEN + NONCE_LEN   # 38
CRC_LEN = 4
MIN_CONTAINER_LEN = HEADER_LEN + 16 + CRC_LEN   # + GCM tag

TEXT_PREFIX = "TC2:"
KIND_TEXT = 0
KIND_FILE = 1

MAX_PLAINTEXT = 200 * 1024 * 1024


# ----------------------------------------------------------------------------
# Chyby (každá má strojový kód + zrozumiteľnú slovenskú správu)
# ----------------------------------------------------------------------------
class TitanError(Exception):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message

    def __str__(self) -> str:
        return self.message


# ----------------------------------------------------------------------------
# Heslo + kľúčový súbor
# ----------------------------------------------------------------------------
def normalize_key(raw: Optional[str]) -> str:
    """Rovnaká normalizácia ako v pôvodnej appke (A–Z, 0–9, max 25 znakov)."""
    if raw is None:
        return ""
    return re.sub(r"[^A-Za-z0-9]", "", raw).upper()[:25]


def require_valid_key(raw: Optional[str]) -> str:
    k = normalize_key(raw)
    if len(k) != 25:
        raise TitanError(
            "BAD_PASSWORD_FORMAT",
            "Kľúč musí mať presne 25 znakov (A–Z, 0–9). "
            f"Rozpoznaných znakov: {len(k)}. Pozor: na slovenskej klávesnici je "
            "číselný riadok bez Shiftu diakritika, ktorú appka ignoruje.",
        )
    return k


def make_keyfile() -> bytes:
    secret = secrets.token_bytes(KEYFILE_SECRET_LEN)
    body = KEYFILE_MAGIC + bytes([APP_FORMAT_VERSION]) + secret
    return body + struct.pack(">I", zlib.crc32(body) & 0xFFFFFFFF)


def parse_keyfile(data: bytes) -> bytes:
    """Vráti 32 B tajomstvo z TC2 .key súboru; inak vyhodí presnú chybu."""
    if len(data) == SALT_LEN:
        raise TitanError(
            "KEYFILE_LEGACY",
            "Toto je starý .key súbor (16 B, formát v1). Použi ho len pri dešifrovaní "
            "starých súborov (bez hlavičky TC2); k tomuto súboru nepatrí.",
        )
    if len(data) != len(KEYFILE_MAGIC) + 1 + KEYFILE_SECRET_LEN + 4:
        raise TitanError(
            "KEYFILE_INVALID",
            f".key súbor má {len(data)} B, očakáva sa 41 B. Súbor bol pravdepodobne "
            "poškodený pri prenose (chat/e-mail ho môže upraviť). Pošli ho v ZIP-e "
            "alebo ako 'súbor/dokument', nie ako text/fotku.",
        )
    if data[:4] != KEYFILE_MAGIC:
        raise TitanError("KEYFILE_INVALID", "Toto nie je TitanCrypt .key súbor (zlá hlavička).")
    if (zlib.crc32(data[:-4]) & 0xFFFFFFFF) != struct.unpack(">I", data[-4:])[0]:
        raise TitanError(
            "KEYFILE_CORRUPT",
            ".key súbor je poškodený (nesedí kontrolný súčet). Pošli ho znova v ZIP-e.",
        )
    return data[5:5 + KEYFILE_SECRET_LEN]


def _kdf(password: str, salt: bytes, log2n: int, r: int, p: int,
         keyfile_secret: Optional[bytes]) -> bytes:
    pw = password.encode("utf-8")
    if keyfile_secret is not None:
        # tajomstvo z .key sa zamieša do hesla (2. faktor)
        pw = hmac.new(keyfile_secret, pw, hashlib.sha256).digest()
    return Scrypt(salt=salt, length=32, n=1 << log2n, r=r, p=p).derive(pw)


def _subkey(master: bytes, info: bytes) -> bytes:
    return HKDFExpand(algorithm=hashes.SHA256(), length=32, info=info).derive(master)


def _check_kdf_params(log2n: int, r: int, p: int) -> None:
    if not (10 <= log2n <= MAX_LOG2N) or not (1 <= r <= MAX_R) or not (1 <= p <= MAX_P):
        raise TitanError(
            "KDF_PARAMS",
            f"Súbor žiada nebezpečné/neplatné KDF parametre (N=2^{log2n}, r={r}, p={p}). "
            "Súbor je poškodený alebo podvrhnutý.",
        )


# ----------------------------------------------------------------------------
# Obálka vnútri šifrovaných dát: kind | name_len(2) | name | data
# ----------------------------------------------------------------------------
def _pack_inner(kind: int, name: str, data: bytes) -> bytes:
    nb = name.encode("utf-8")[:255]
    return bytes([kind]) + struct.pack(">H", len(nb)) + nb + data


@dataclass
class Opened:
    kind: int           # KIND_TEXT / KIND_FILE
    name: str
    data: bytes
    format_version: int  # 2 = TC2, 1 = starý formát

    @property
    def text(self) -> str:
        return self.data.decode("utf-8")


def _unpack_inner(buf: bytes) -> Tuple[int, str, bytes]:
    if len(buf) < 3:
        raise TitanError("BAD_FORMAT", "Dešifrované dáta majú neplatnú štruktúru.")
    kind = buf[0]
    nlen = struct.unpack(">H", buf[1:3])[0]
    if len(buf) < 3 + nlen:
        raise TitanError("BAD_FORMAT", "Dešifrované dáta majú neplatnú štruktúru.")
    name = buf[3:3 + nlen].decode("utf-8", "replace")
    return kind, name, buf[3 + nlen:]


# ----------------------------------------------------------------------------
# TC2 šifrovanie / dešifrovanie
# ----------------------------------------------------------------------------
def encrypt(data: bytes, password: str, *, kind: int = KIND_FILE, name: str = "",
            keyfile: Optional[bytes] = None) -> bytes:
    """Zašifruje `data`. Ak je `keyfile` zadaný (bytes z make_keyfile), je povinný aj pri dešifrovaní."""
    password = require_valid_key(password)
    if len(data) > MAX_PLAINTEXT:
        raise TitanError("TOO_LARGE", "Vstup je príliš veľký.")
    secret = parse_keyfile(keyfile) if keyfile is not None else None
    salt = secrets.token_bytes(SALT_LEN)
    nonce = secrets.token_bytes(NONCE_LEN)
    flags = FLAG_KEYFILE if secret is not None else 0
    header = (MAGIC + bytes([APP_FORMAT_VERSION, flags, KDF_SCRYPT, DEFAULT_LOG2N, DEFAULT_R, DEFAULT_P])
              + salt + nonce)
    key = _subkey(_kdf(password, salt, DEFAULT_LOG2N, DEFAULT_R, DEFAULT_P, secret), b"TitanCrypt/v2/enc")
    ct = AESGCM(key).encrypt(nonce, _pack_inner(kind, name, data), header)
    body = header + ct
    return body + struct.pack(">I", zlib.crc32(body) & 0xFFFFFFFF)


def fingerprint(blob: bytes) -> str:
    """Krátky odtlačok na porovnanie 'čo som poslal' vs 'čo prišlo': veľkosť + SHA-256 (12 znakov)."""
    return f"{len(blob)} B, SHA-256 {hashlib.sha256(blob).hexdigest()[:12]}"


def inspect_container(blob: bytes) -> dict:
    """Bezpečne (bez hesla) povie, čo to za súbor je. Slúži na diagnostiku."""
    if blob[:4] == MAGIC and len(blob) >= HEADER_LEN:
        return {"format": "TC2", "version": blob[4], "needs_keyfile": bool(blob[5] & FLAG_KEYFILE),
                "kdf": {"id": blob[6], "log2n": blob[7], "r": blob[8], "p": blob[9]},
                "size": len(blob)}
    if blob[:4] == STEGO_MAGIC:
        return {"format": "TCSG-container?", "size": len(blob)}
    return {"format": "unknown/legacy", "size": len(blob)}


def decrypt(blob: bytes, password: str, *, keyfile: Optional[bytes] = None) -> Opened:
    password = require_valid_key(password)
    if blob[:4] == MAGIC:
        return _decrypt_v2(blob, password, keyfile)
    return _decrypt_legacy_v1_file(blob, password, keyfile)


def _decrypt_v2(blob: bytes, password: str, keyfile: Optional[bytes]) -> Opened:
    if len(blob) < MIN_CONTAINER_LEN:
        raise TitanError("TRUNCATED", "Súbor je príliš krátky — pravdepodobne sa nestiahol/neodoslal celý.")
    version, flags, kdf_id, log2n, r, p = blob[4], blob[5], blob[6], blob[7], blob[8], blob[9]
    if version != 2:
        raise TitanError(
            "UNSUPPORTED_VERSION",
            f"Súbor má formát verzie {version}, táto appka rozumie verzii 2. "
            "Kamarát/ty používate rôzne zostavy — aktualizujte obe na rovnakú verziu.",
        )
    if kdf_id != KDF_SCRYPT:
        raise TitanError("UNSUPPORTED_KDF", f"Neznáma KDF funkcia ({kdf_id}). Aktualizuj appku.")
    _check_kdf_params(log2n, r, p)

    body, crc = blob[:-CRC_LEN], struct.unpack(">I", blob[-CRC_LEN:])[0]
    if (zlib.crc32(body) & 0xFFFFFFFF) != crc:
        raise TitanError(
            "CORRUPTED",
            "Súbor je poškodený (nesedí kontrolný súčet) — NIE je to chyba hesla. "
            "Najčastejšie: prenos cez chat/sociálnu sieť, ktorá súbor upravila alebo skrátila. "
            "Pošli ho znova ako 'súbor/dokument' alebo v ZIP-e.",
        )

    needs_keyfile = bool(flags & FLAG_KEYFILE)
    if needs_keyfile and keyfile is None:
        raise TitanError("KEYFILE_REQUIRED", "Tento súbor bol zašifrovaný aj s .key súborom — nahraj ho.")
    if not needs_keyfile and keyfile is not None:
        keyfile = None  # zbytočný .key ignorujeme, súbor ho nepoužíva
    secret = parse_keyfile(keyfile) if keyfile is not None else None

    header = body[:HEADER_LEN]
    salt = header[10:10 + SALT_LEN]
    nonce = header[10 + SALT_LEN:HEADER_LEN]
    ct = body[HEADER_LEN:]
    key = _subkey(_kdf(password, salt, log2n, r, p, secret), b"TitanCrypt/v2/enc")
    try:
        inner = AESGCM(key).decrypt(nonce, ct, header)
    except InvalidTag:
        raise TitanError(
            "WRONG_PASSWORD",
            "Nesprávny kľúč" + (" alebo nesprávny .key súbor" if needs_keyfile else "") +
            ". Súbor je celý a nepoškodený (kontrolný súčet sedí), chyba je v kľúči.",
        )
    kind, name, data = _unpack_inner(inner)
    return Opened(kind, name, data, 2)


# ----------------------------------------------------------------------------
# Spätná kompatibilita so starým formátom v1 (aktuálna Win11 verzia pred opravou)
#   obrázok: nonce(12)+ciphertext+tag ; .key: salt(16) ; scrypt N=2^14,r=8,p=1 ; bez AAD
#   text:    hex(salt16 + nonce12 + ciphertext+tag)
# ----------------------------------------------------------------------------
_V1_N, _V1_R, _V1_P = 2 ** 14, 8, 1


def _v1_key(password: str, salt: bytes) -> bytes:
    return Scrypt(salt=salt, length=32, n=_V1_N, r=_V1_R, p=_V1_P).derive(password.encode("utf-8"))


def _decrypt_legacy_v1_file(blob: bytes, password: str, keyfile: Optional[bytes]) -> Opened:
    if keyfile is None:
        raise TitanError(
            "LEGACY_NEEDS_KEY",
            "Súbor nezačína TC2 hlavičkou 'TCRY' (" + fingerprint(blob) + ", začiatok " + blob[:4].hex() + "). "
            "Možnosti: (1) je to súbor zo starého formátu — ten vyžaduje 16 B .key; (2) toto vôbec nie je "
            ".tcrypt súbor (napr. si vybral pôvodný obrázok alebo iný súbor); (3) súbor sa pri prenose zmenil. "
            "Porovnaj veľkosť a odtlačok s tým, čo zobrazila appka odosielateľovi po zašifrovaní.",
        )
    if len(keyfile) != SALT_LEN:
        # presne ten prípad "zlý salt", teraz s vysvetlením
        hint = ""
        if keyfile[:4] == KEYFILE_MAGIC:
            hint = " Tento .key je z NOVEJ verzie (TC2) — ale šifrovaný súbor je zo STAREJ; nepatria k sebe."
        elif len(keyfile) > SALT_LEN:
            hint = (" .key je dlhší než 16 B — je to buď .key z úplne starej XOR verzie (tá je "
                    "nekompatibilná), alebo ho prenos zmenil (pridané znaky/koniec riadku).")
        else:
            hint = " .key je kratší než 16 B — súbor sa pri prenose skrátil."
        raise TitanError("BAD_SALT",
                         f"Zlá dĺžka salt: .key má {len(keyfile)} B, očakáva sa 16 B.{hint}")
    if len(blob) < NONCE_LEN + 16:
        raise TitanError("TRUNCATED", "Zašifrovaný súbor je príliš krátky alebo poškodený.")
    nonce, ct = blob[:NONCE_LEN], blob[NONCE_LEN:]
    try:
        data = AESGCM(_v1_key(password, keyfile)).decrypt(nonce, ct, None)
    except InvalidTag:
        raise TitanError(
            "WRONG_PASSWORD_OR_PAIR",
            "Nesprávny kľúč, alebo .key nepatrí k tomuto súboru, alebo je súbor poškodený "
            "(starý formát nevie tieto prípady rozlíšiť — preto je nový formát TC2).",
        )
    return Opened(KIND_FILE, "", data, 1)


def _clean_text_blob(s: str) -> str:
    # chat appky vkladajú medzery, nové riadky, úvodzovky, zero-width znaky
    s = re.sub(r"[\s\u200b\u200c\u200d\ufeff\"'`<>]", "", s)
    return s


def text_encrypt(plain: str, password: str, *, keyfile: Optional[bytes] = None) -> str:
    if not plain:
        raise TitanError("EMPTY", "Zadaj text.")
    blob = encrypt(plain.encode("utf-8"), password, kind=KIND_TEXT, keyfile=keyfile)
    return TEXT_PREFIX + base64.urlsafe_b64encode(blob).decode("ascii").rstrip("=")


def text_decrypt(armored: str, password: str, *, keyfile: Optional[bytes] = None) -> str:
    s = _clean_text_blob(armored or "")
    if not s:
        raise TitanError("EMPTY", "Zadaj zašifrovaný text.")
    password = require_valid_key(password)

    if s.startswith(TEXT_PREFIX):
        b64 = s[len(TEXT_PREFIX):]
        if not re.fullmatch(r"[A-Za-z0-9_\-]+", b64):
            raise TitanError("BAD_FORMAT", "Text po 'TC2:' obsahuje neplatné znaky — text sa pri kopírovaní pokazil.")
        try:
            blob = base64.urlsafe_b64decode(b64 + "=" * (-len(b64) % 4))
        except Exception:
            raise TitanError("BAD_FORMAT", "Text sa nedá dekódovať — pravdepodobne je skrátený.")
        res = _decrypt_v2(blob, password, keyfile) if blob[:4] == MAGIC else None
        if res is None:
            raise TitanError("BAD_FORMAT", "Text po 'TC2:' neobsahuje platný TitanCrypt kontajner.")
        return res.text

    # starý formát v1: holý hex (salt+nonce+ct)
    if re.fullmatch(r"[0-9a-fA-F]+", s) and len(s) % 2 == 0:
        raw = bytes.fromhex(s)
        if len(raw) <= SALT_LEN + NONCE_LEN + 16:
            raise TitanError("TRUNCATED", "Zašifrovaný text je príliš krátky — skrátil sa pri kopírovaní.")
        salt, nonce, ct = raw[:SALT_LEN], raw[SALT_LEN:SALT_LEN + NONCE_LEN], raw[SALT_LEN + NONCE_LEN:]
        try:
            return AESGCM(_v1_key(password, salt)).decrypt(nonce, ct, None).decode("utf-8")
        except InvalidTag:
            raise TitanError(
                "WRONG_PASSWORD_OR_CORRUPT",
                "Starý formát (hex): nesprávny kľúč ALEBO text je poškodený/skrátený — starý "
                "formát to nevie rozlíšiť. Nový formát (začína 'TC2:') to rozlišuje.",
            )
    raise TitanError(
        "BAD_FORMAT",
        "Nerozpoznaný formát. Nový text začína 'TC2:'. Ak ide o veľmi starý XOR text (hex s "
        "dĺžkou v prvých 4 znakoch), ten táto verzia zámerne nepodporuje (XOR sa dá prelomiť).",
    )


# ----------------------------------------------------------------------------
# STEGO (LSB v RGB kanáloch, šifrovaný obsah rozptýlený podľa kľúča)
# ----------------------------------------------------------------------------
STEGO_HEADER_LEN = 4 + 1 + 1 + 1 + 1 + 1 + SALT_LEN + NONCE_LEN + 4   # 41 B
STEGO_HEADER_BITS = STEGO_HEADER_LEN * 8                               # 328
STEGO_MAX_PIXELS = 16_000_000


def _np():
    try:
        import numpy as np
        return np
    except ImportError:  # pragma: no cover
        raise TitanError("NO_NUMPY", "Stego vyžaduje balík numpy (pip install numpy).")


def _feistel_positions(count: int, domain: int, pos_key: bytes):
    """
    Prvých `count` prvkov kľúčom riadenej permutácie množiny [0, domain).
    Feistel sieť na 2^bits + cycle-walking => bijekcia => žiadne kolízie pozícií.
    Iba uint64 aritmetika => reprodukovateľné na každej platforme/verzii NumPy.
    """
    np = _np()
    bits = max(2, (domain - 1).bit_length())
    if bits % 2:
        bits += 1
    half = bits // 2
    mask = np.uint64((1 << half) - 1)
    rounds = [np.uint64(int.from_bytes(hashlib.sha256(pos_key + bytes([i])).digest()[:8], "big"))
              for i in range(6)]
    c1 = np.uint64(0x9E3779B97F4A7C15)
    c2 = np.uint64(0xBF58476D1CE4E5B9)
    s29, s32, sh = np.uint64(29), np.uint64(32), np.uint64(half)

    def f(x, k):
        x = (x ^ k) * c1
        x ^= x >> s29
        x = x * c2
        x ^= x >> s32
        return x & mask

    def enc(v):
        left, right = v >> sh, v & mask
        for k in rounds:
            left, right = right, left ^ f(right, k)
        return (left << sh) | right

    dom = np.uint64(domain)
    result = np.empty(count, dtype=np.int64)
    block = 1 << 20                     # po blokoch => nízka špička RAM aj pri veľkých obrázkoch
    for start in range(0, count, block):
        end = min(count, start + block)
        out = enc(np.arange(start, end, dtype=np.uint64))
        bad = out >= dom
        while bad.any():
            out[bad] = enc(out[bad])
            bad = out >= dom
        result[start:end] = out.astype(np.int64)
    return result


def stego_capacity_bytes(width: int, height: int) -> int:
    """Max. veľkosť šifrovaného obsahu (vrátane inner obálky + 16 B GCM tag + 4 B CRC)."""
    slots = width * height * 3 - STEGO_HEADER_BITS
    return max(0, slots // 8 - CRC_LEN)


def _load_cover(cover_bytes: bytes):
    np = _np()
    from PIL import Image
    try:
        img = Image.open(io.BytesIO(cover_bytes))
        img.load()
    except Exception as e:
        raise TitanError("BAD_COVER", f"Obrázok sa nedá otvoriť: {e}")
    if img.size[0] * img.size[1] > STEGO_MAX_PIXELS:
        raise TitanError("COVER_TOO_BIG", "Obrázok je príliš veľký (max ~16 Mpx). Zmenši ho.")
    has_alpha = img.mode in ("RGBA", "LA") or (img.mode == "P" and "transparency" in img.info)
    rgba = img.convert("RGBA") if has_alpha else None
    rgb = img.convert("RGB")
    arr = np.frombuffer(rgb.tobytes(), dtype=np.uint8).copy()
    alpha = None if rgba is None else rgba.getchannel("A")
    return arr, rgb.size, alpha


def stego_hide(cover_bytes: bytes, secret: bytes, password: str, *, kind: int = KIND_FILE,
               name: str = "", keyfile: Optional[bytes] = None) -> bytes:
    """Vráti PNG s ukrytým šifrovaným obsahom."""
    np = _np()
    from PIL import Image
    password = require_valid_key(password)
    sec = parse_keyfile(keyfile) if keyfile is not None else None
    arr, (w, h), alpha = _load_cover(cover_bytes)

    salt = secrets.token_bytes(SALT_LEN)
    nonce = secrets.token_bytes(NONCE_LEN)
    flags = FLAG_KEYFILE if sec is not None else 0
    inner = _pack_inner(kind, name, secret)
    ct_len = len(inner) + 16
    header = (STEGO_MAGIC + bytes([1, flags, DEFAULT_LOG2N, DEFAULT_R, DEFAULT_P])
              + salt + nonce + struct.pack(">I", ct_len))
    master = _kdf(password, salt, DEFAULT_LOG2N, DEFAULT_R, DEFAULT_P, sec)
    ct = AESGCM(_subkey(master, b"TitanCrypt/stego/enc")).encrypt(nonce, inner, header)
    payload = ct + struct.pack(">I", zlib.crc32(header + ct) & 0xFFFFFFFF)

    slots = arr.size - STEGO_HEADER_BITS
    need = len(payload) * 8
    if need > slots:
        raise TitanError(
            "NO_CAPACITY",
            f"Obrázok je primalý: potrebuje {len(payload)} B, kapacita je {stego_capacity_bytes(w, h)} B. "
            "Použi väčší obrázok alebo menšie tajomstvo.",
        )

    hbits = np.unpackbits(np.frombuffer(header, dtype=np.uint8))
    arr[:STEGO_HEADER_BITS] = (arr[:STEGO_HEADER_BITS] & 0xFE) | hbits
    pbits = np.unpackbits(np.frombuffer(payload, dtype=np.uint8))
    pos = _feistel_positions(need, slots, _subkey(master, b"TitanCrypt/stego/pos")) + STEGO_HEADER_BITS
    arr[pos] = (arr[pos] & 0xFE) | pbits

    out = Image.frombytes("RGB", (w, h), arr.tobytes())
    if alpha is not None:
        out = out.convert("RGBA")
        out.putalpha(alpha)
    buf = io.BytesIO()
    out.save(buf, format="PNG")
    return buf.getvalue()


def stego_extract(stego_png: bytes, password: str, *, keyfile: Optional[bytes] = None) -> Opened:
    np = _np()
    password = require_valid_key(password)
    arr, (w, h), _ = _load_cover(stego_png)
    if arr.size < STEGO_HEADER_BITS:
        raise TitanError("NO_STEGO", "Obrázok je príliš malý na to, aby obsahoval TitanCrypt dáta.")
    header = np.packbits(arr[:STEGO_HEADER_BITS] & 1).tobytes()
    if header[:4] != STEGO_MAGIC:
        raise TitanError(
            "NO_STEGO",
            "V obrázku sa nenašla TitanCrypt hlavička. Buď v ňom nič nie je, alebo bol obrázok po "
            "vložení dát zmenený (JPEG kompresia, zmenšenie, 'fotka' v Messengeri/Instagrame/WhatsAppe). "
            "Pošli PNG ako SÚBOR/DOKUMENT.",
        )
    version, flags, log2n, r, p = header[4], header[5], header[6], header[7], header[8]
    if version != 1:
        raise TitanError("UNSUPPORTED_VERSION", f"Stego verzia {version} nie je podporovaná. Aktualizuj appku.")
    _check_kdf_params(log2n, r, p)
    salt = header[9:9 + SALT_LEN]
    nonce = header[9 + SALT_LEN:9 + SALT_LEN + NONCE_LEN]
    ct_len = struct.unpack(">I", header[-4:])[0]
    slots = arr.size - STEGO_HEADER_BITS
    need = (ct_len + CRC_LEN) * 8
    if ct_len < 16 + 3 or need > slots:
        raise TitanError("CORRUPTED", "Hlavička stego dát je neplatná — obrázok bol pravdepodobne upravený.")

    needs_keyfile = bool(flags & FLAG_KEYFILE)
    if needs_keyfile and keyfile is None:
        raise TitanError("KEYFILE_REQUIRED", "Tieto dáta boli ukryté aj s .key súborom — nahraj ho.")
    sec = parse_keyfile(keyfile) if (needs_keyfile and keyfile is not None) else None

    master = _kdf(password, salt, log2n, r, p, sec)
    pos = _feistel_positions(need, slots, _subkey(master, b"TitanCrypt/stego/pos")) + STEGO_HEADER_BITS
    payload = np.packbits(arr[pos] & 1).tobytes()
    ct, crc = payload[:-CRC_LEN], struct.unpack(">I", payload[-CRC_LEN:])[0]
    if (zlib.crc32(header + ct) & 0xFFFFFFFF) != crc:
        # CRC nesedí: buď zlé heslo (zlé pozície bitov), alebo poškodený obrázok. Rozlíšiť sa to
        # kryptograficky nedá, lebo pozície závisia od hesla — preto spoločná, úprimná správa.
        raise TitanError(
            "WRONG_PASSWORD_OR_CORRUPT",
            "Dáta sa nepodarilo overiť: nesprávny kľúč" + (" / .key" if needs_keyfile else "") +
            " ALEBO bol obrázok po vložení dát zmenený (kompresia/zmenšenie/prekódovanie).",
        )
    try:
        inner = AESGCM(_subkey(master, b"TitanCrypt/stego/enc")).decrypt(nonce, ct, header)
    except InvalidTag:
        raise TitanError("CORRUPTED", "Dáta sú poškodené (autentifikácia zlyhala).")
    kind, name, data = _unpack_inner(inner)
    return Opened(kind, name, data, 1)
