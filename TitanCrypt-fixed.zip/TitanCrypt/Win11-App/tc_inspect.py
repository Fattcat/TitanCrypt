"""Diagnostika bez hesla: čo je to za súbor?   python tc_inspect.py subor.tcrypt|subor.key|obrazok.png"""
import sys
import titancrypt_core as tc

for path in sys.argv[1:]:
    b = open(path, "rb").read()
    if b[:4] == tc.KEYFILE_MAGIC:
        ok = "OK" if len(b) == 41 else f"ZLÁ DĹŽKA ({len(b)} B, má byť 41)"
        print(f"{path}: TC2 .key súbor, {ok}")
    elif len(b) == 16:
        print(f"{path}: 16 B => starý .key (formát v1, holý salt)")
    elif b[:4] == tc.MAGIC:
        i = tc.inspect_container(b)
        print(f"{path}: {i}")
    elif b[:8] == b"\x89PNG\r\n\x1a\n":
        print(f"{path}: PNG ({len(b)} B) – ak ide o stego, skús ho vo 'Vytiahnuť' (hlavičku vidno len po dekódovaní pixelov)")
    else:
        print(f"{path}: {len(b)} B, bez TC2 hlavičky => starý formát v1 (potrebuje 16 B .key) alebo cudzí súbor")
