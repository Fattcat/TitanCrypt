import io
import re
import time
import threading
import os
import shutil
import webbrowser
import sys
import socket
import secrets
import json
from datetime import datetime
from pathlib import Path
from PIL import Image
from collections import defaultdict

# Celá kryptografia je v titancrypt_core.py (verzovaný formát TC2, testy v tests/)
import titancrypt_core as core

# Tkinter import (iba ak bežíme ako GUI appka)
USE_GUI = "--no-gui" not in sys.argv
if USE_GUI:
    import tkinter as tk
    from tkinter import messagebox, font, ttk

from flask import Flask, request, render_template_string, send_file, jsonify
from werkzeug.serving import make_server

APP_VERSION = "2.0"


def _resource_dir() -> Path:
    """Priečinok s logom/ikonou: v .exe (PyInstaller) je to _MEIPASS, inak priečinok skriptu."""
    base = getattr(sys, "_MEIPASS", None)
    return Path(base) if base else Path(__file__).resolve().parent


def _user_data_dir() -> Path:
    """Kam sa ukladá história. Predtým natvrdo C:/TitanCrypt (na cudzom PC nemusí byť zapisovateľné)."""
    base = (os.environ.get("LOCALAPPDATA") or os.environ.get("XDG_DATA_HOME")
            or str(Path.home() / ".local" / "share"))
    return Path(base) / "TitanCrypt"


# === NASTAVENIA ===
STATIC_DIR = _resource_dir() / "static"
HISTORY_ROOT = _user_data_dir()
HOST = "127.0.0.1"
DEFAULT_PORT = 5000
MAX_PORT_ATTEMPTS = 10
ALLOWED_HOSTNAMES = {"127.0.0.1", "localhost"}

app = Flask(__name__, static_folder=str(STATIC_DIR))
# Náhodný secret_key generovaný pri každom štarte
app.secret_key = secrets.token_hex(32)
# Obmedzenie veľkosti uploadu (64 MB) - ochrana proti DoS
app.config["MAX_CONTENT_LENGTH"] = 64 * 1024 * 1024

# Výsledky operácií (appka je jednopoužívateľská, beží len na 127.0.0.1)
STATE = {
    "enc_blob": None, "enc_name": "encrypted.tcrypt", "enc_keyfile": None, "enc_info": "",
    "dec": None,                       # core.Opened
    "stego_png": None, "stego_keyfile": None,
    "stego_out": None,                 # core.Opened
}
_encrypted_text = None
_original_text_length = 0
_encrypted_text_length = 0
_decrypted_text = None
task_status = defaultdict(lambda: {"progress": 0, "eta": 0, "done": False, "error": None, "result": None, "cancelled": False})

# Server kontrola
server_instance = None
server_thread = None
stop_event = threading.Event()


# === UTILS ===
def is_port_free(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind((HOST, port))
            return True
        except OSError:
            return False

def find_free_port(start_port=DEFAULT_PORT, max_attempts=MAX_PORT_ATTEMPTS):
    for offset in range(max_attempts):
        port = start_port + offset
        if is_port_free(port):
            return port
    raise RuntimeError(f"Žiadny voľný port medzi {start_port}–{start_port + max_attempts - 1}")


# === HISTORY ===
# POZOR (zmena): história už NEUKLADÁ heslo (key.txt) ani pôvodný text/obrázok v čistom
# texte. Pôvodná verzia ich ukladala do C:/TitanCrypt/... čím sa šifrovanie fakticky
# obchádzalo (kto mal prístup k disku, mal heslo aj originál). Ukladá sa len to, čo si
# aj tak posielaš: zašifrovaný výstup (a .key, ak si ho vytvoril).
def ensure_history_dirs():
    try:
        (HISTORY_ROOT / "TextCrypt").mkdir(parents=True, exist_ok=True)
        (HISTORY_ROOT / "ImgCrypt").mkdir(parents=True, exist_ok=True)
    except Exception as e:
        print(f"[HIST] Chyba: {e}")


def _history_folder(top: str) -> Path:
    ensure_history_dirs()
    ts = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    folder = HISTORY_ROOT / top / f"Encrypted_{ts}"
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def save_text_history(encrypted_text: str):
    try:
        (_history_folder("TextCrypt") / "EncryptedText.txt").write_text(encrypted_text, encoding="utf-8")
    except Exception as e:
        print(f"[HIST] Text chyba: {e}")


def save_image_history(blob: bytes, keyfile):
    try:
        folder = _history_folder("ImgCrypt")
        (folder / "encrypted.tcrypt").write_bytes(blob)
        if keyfile:
            (folder / "decryption_key.key").write_bytes(keyfile)
    except Exception as e:
        print(f"[HIST] Img chyba: {e}")


# === CORE LOGIC ===
_IMG_MIME = {"PNG": ("image/png", "png"), "JPEG": ("image/jpeg", "jpg"), "GIF": ("image/gif", "gif"),
             "WEBP": ("image/webp", "webp"), "BMP": ("image/bmp", "bmp")}


def sniff_image(data: bytes):
    """(mimetype, ext) iba pre rastrové obrázky, ktoré vieme bezpečne zobraziť; inak (None, None)."""
    try:
        with Image.open(io.BytesIO(data)) as im:
            return _IMG_MIME.get((im.format or "").upper(), (None, None))
    except Exception:
        return None, None


def safe_name(name: str, default: str) -> str:
    n = Path(name or "").name
    n = re.sub(r"[^A-Za-z0-9._\-]", "_", n)[:80].strip("._")
    return n or default


def err_text(e: Exception) -> str:
    return e.message if isinstance(e, core.TitanError) else f"Neočakávaná chyba: {e}"


def get_step_delay(mode):
    delays = {"high": 0.005, "medium": 0.015, "slow": 0.04, "veryslow": 0.1}
    return delays.get(mode, 0.015)


def simulate_progress_with_mode(task_id, total_steps=100, mode="medium"):
    delay = get_step_delay(mode)
    for i in range(1, total_steps + 1):
        if task_status[task_id].get("cancelled") or stop_event.is_set():
            return False
        task_status[task_id]["progress"] = i
        remaining = total_steps - i
        task_status[task_id]["eta"] = round(remaining * delay, 1)
        time.sleep(delay)
    return True


def encrypt_task(task_id, file_bytes, key_raw, mode="medium", original_filename="file", use_keyfile=False):
    try:
        key_clean = core.require_valid_key(key_raw)
        if not simulate_progress_with_mode(task_id, total_steps=80, mode=mode):
            task_status[task_id]["error"] = "Zrušené"
            return
        keyfile = core.make_keyfile() if use_keyfile else None
        name = safe_name(original_filename, "file")
        blob = core.encrypt(file_bytes, key_clean, kind=core.KIND_FILE, name=name, keyfile=keyfile)
        # self-check: výsledok hneď skúsime dešifrovať, nech nikdy neodovzdáme nepoužiteľný súbor
        if core.decrypt(blob, key_clean, keyfile=keyfile).data != file_bytes:
            raise core.TitanError("SELFCHECK", "Vnútorná kontrola zlyhala (šifrovanie nedalo spätne čitateľný výsledok).")
        STATE["enc_blob"], STATE["enc_keyfile"] = blob, keyfile
        STATE["enc_info"] = core.fingerprint(blob)
        STATE["enc_name"] = safe_name(Path(name).stem, "encrypted") + ".tcrypt"
        save_image_history(blob, keyfile)
        task_status[task_id]["done"] = True
        task_status[task_id]["result"] = "encrypt_success"
    except Exception as e:
        task_status[task_id]["error"] = err_text(e)


def decrypt_task(task_id, blob, keyfile_bytes, user_key, mode="medium"):
    try:
        key_clean = core.require_valid_key(user_key)
        if not simulate_progress_with_mode(task_id, total_steps=80, mode=mode):
            task_status[task_id]["error"] = "Zrušené"
            return
        STATE["dec"] = core.decrypt(blob, key_clean, keyfile=keyfile_bytes)
        task_status[task_id]["done"] = True
        task_status[task_id]["result"] = "decrypt_success"
    except Exception as e:
        task_status[task_id]["error"] = err_text(e)


# === CSRF / DNS-REBINDING / HLAVIČKY ===
# Server počúva len na 127.0.0.1, ale škodlivá stránka v tom istom prehliadači môže
# posielať požiadavky na http://127.0.0.1:PORT (localhost CSRF) alebo cez DNS rebinding
# čítať výsledky. Preto: (1) Host musí byť 127.0.0.1/localhost, (2) každý POST musí mať
# pôvod z localhostu, (3) prísne bezpečnostné hlavičky.
@app.before_request
def _local_only_guard():
    hostname = (request.host or "").rsplit(":", 1)[0].strip("[]").lower()
    if hostname not in ALLOWED_HOSTNAMES:
        return jsonify({"error": "Zakázaný Host (ochrana proti DNS rebindingu)"}), 403
    if request.method not in ("GET", "HEAD", "OPTIONS"):
        origin = request.headers.get("Origin") or request.headers.get("Referer") or ""
        allowed = tuple(f"{sch}://{h}:" for sch in ("http", "https") for h in ALLOWED_HOSTNAMES)
        if origin and not origin.startswith(allowed):
            return jsonify({"error": "Zakázaný pôvod požiadavky (CSRF ochrana)"}), 403
    return None


@app.after_request
def _security_headers(resp):
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Referrer-Policy"] = "no-referrer"
    resp.headers["Cache-Control"] = "no-store"
    resp.headers["Content-Security-Policy"] = (
        "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; "
        "script-src 'self' 'unsafe-inline'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
    return resp


@app.errorhandler(413)
def _too_large(_e):
    return jsonify({"error": "Súbor je príliš veľký (limit 64 MB)."}), 413


# === FLASK ROUTES ===
@app.route("/", methods=["GET"])
def index():
    task = request.args.get("task")
    ctx = {"app_version": APP_VERSION}
    if task == "encrypt_success" and STATE["enc_blob"] is not None:
        ctx["enc_success"] = True
        ctx["enc_has_key"] = STATE["enc_keyfile"] is not None
        ctx["enc_info"] = STATE["enc_info"]
    elif task == "decrypt_success" and STATE["dec"] is not None:
        d = STATE["dec"]
        mt, ext = sniff_image(d.data)
        ctx["dec_ready"] = True
        ctx["dec_is_image"] = mt is not None
        ctx["dec_is_text"] = d.kind == core.KIND_TEXT
        ctx["dec_text"] = d.data.decode("utf-8", "replace") if d.kind == core.KIND_TEXT else ""
        ctx["dec_filename"] = dec_download_name(d)
        ctx["dec_legacy"] = d.format_version == 1
    elif task == "stego_hide_success" and STATE["stego_png"] is not None:
        ctx["stego_hide_ok"] = True
        ctx["stego_has_key"] = STATE["stego_keyfile"] is not None
    elif task == "stego_extract_success" and STATE["stego_out"] is not None:
        o = STATE["stego_out"]
        mt, _ = sniff_image(o.data)
        ctx["stego_out_ready"] = True
        ctx["stego_out_is_text"] = o.kind == core.KIND_TEXT
        ctx["stego_out_text"] = o.data.decode("utf-8", "replace") if o.kind == core.KIND_TEXT else ""
        ctx["stego_out_is_image"] = mt is not None
        ctx["stego_out_filename"] = dec_download_name(o)
    return render_template_string(INDEX_HTML, **ctx)


def dec_download_name(o) -> str:
    if o.name:
        return safe_name(o.name, "decrypted")
    _, ext = sniff_image(o.data)           # starý formát v1 nemal názov súboru
    return f"decrypted.{ext or 'bin'}"


def _optional_upload(field: str):
    f = request.files.get(field)
    if f is None or not f.filename:
        return None
    data = f.read()
    return data or None


@app.route("/start_encrypt", methods=["POST"])
def start_encrypt():
    try:
        if "image" not in request.files:
            return jsonify({"error": "Nebol vybraný súbor"}), 400
        file = request.files["image"]
        key_raw = request.form.get("key", "")
        mode = request.form.get("speed_mode", "medium")
        use_keyfile = request.form.get("use_keyfile") == "1"
        file_bytes = file.read()
        if not file_bytes:
            return jsonify({"error": "Súbor je prázdny"}), 400
        task_id = str(time.time()).replace(".", "")
        threading.Thread(target=encrypt_task,
                         args=(task_id, file_bytes, key_raw, mode, file.filename, use_keyfile),
                         daemon=True).start()
        return jsonify({"task_id": task_id})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/start_decrypt", methods=["POST"])
def start_decrypt():
    try:
        if "image_file" not in request.files:
            return jsonify({"error": "Chýba zašifrovaný súbor"}), 400
        blob = request.files["image_file"].read()
        keyfile_bytes = _optional_upload("key_file")      # .key je voliteľný (povinný len ak ho súbor vyžaduje)
        user_key = request.form.get("key", "")
        mode = request.form.get("speed_mode", "medium")
        if not blob:
            return jsonify({"error": "Zašifrovaný súbor je prázdny"}), 400
        task_id = str(time.time()).replace(".", "")
        threading.Thread(target=decrypt_task, args=(task_id, blob, keyfile_bytes, user_key, mode),
                         daemon=True).start()
        return jsonify({"task_id": task_id})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/cancel_task/<task_id>", methods=["POST"])
def cancel_task(task_id):
    task_status[task_id]["cancelled"] = True
    return jsonify({"status": "cancelled"})


@app.route("/status/<task_id>")
def task_status_route(task_id):
    return jsonify(task_status[task_id])


@app.route("/download_encrypted_image")
def download_encrypted_image():
    if STATE["enc_blob"] is None:
        return "Žiadny súbor", 404
    return send_file(io.BytesIO(STATE["enc_blob"]), mimetype="application/octet-stream",
                     as_attachment=True, download_name=STATE["enc_name"])


@app.route("/download_decryption_key")
def download_decryption_key():
    if STATE["enc_keyfile"] is None:
        return "Žiadny .key súbor (nebol vytvorený)", 404
    return send_file(io.BytesIO(STATE["enc_keyfile"]), mimetype="application/octet-stream",
                     as_attachment=True, download_name="decryption_key.key")


def _send_opened(o, inline: bool):
    mt, _ = sniff_image(o.data)
    if inline:
        if mt is None:
            return "Nie je obrázok", 404
        return send_file(io.BytesIO(o.data), mimetype=mt)
    return send_file(io.BytesIO(o.data), mimetype=mt or "application/octet-stream",
                     as_attachment=True, download_name=dec_download_name(o))


@app.route("/preview_decrypted")
def preview_decrypted():
    if STATE["dec"] is None:
        return "No data", 404
    return _send_opened(STATE["dec"], inline=True)


@app.route("/download_decrypted")
def download_decrypted():
    if STATE["dec"] is None:
        return "Žiadny súbor", 404
    return _send_opened(STATE["dec"], inline=False)


# ---- STEGO ----
@app.route("/stego_hide", methods=["POST"])
def stego_hide_route():
    try:
        cover = _optional_upload("cover")
        if cover is None:
            return jsonify({"error": "Vyber krycí obrázok"}), 400
        key = core.require_valid_key(request.form.get("key", ""))
        secret_file = request.files.get("secret_file")
        if secret_file is not None and secret_file.filename:
            secret, kind, name = secret_file.read(), core.KIND_FILE, safe_name(secret_file.filename, "secret.bin")
        else:
            text = request.form.get("secret_text", "")
            if not text.strip():
                return jsonify({"error": "Zadaj tajný text alebo vyber súbor"}), 400
            secret, kind, name = text.encode("utf-8"), core.KIND_TEXT, ""
        keyfile = core.make_keyfile() if request.form.get("use_keyfile") == "1" else None
        png = core.stego_hide(cover, secret, key, kind=kind, name=name, keyfile=keyfile)
        STATE["stego_png"], STATE["stego_keyfile"] = png, keyfile
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"error": err_text(e)}), 400


@app.route("/stego_extract", methods=["POST"])
def stego_extract_route():
    try:
        img = _optional_upload("stego_image")
        if img is None:
            return jsonify({"error": "Vyber obrázok s ukrytými dátami"}), 400
        key = core.require_valid_key(request.form.get("key", ""))
        STATE["stego_out"] = core.stego_extract(img, key, keyfile=_optional_upload("key_file"))
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"error": err_text(e)}), 400


@app.route("/download_stego")
def download_stego():
    if STATE["stego_png"] is None:
        return "Žiadny súbor", 404
    return send_file(io.BytesIO(STATE["stego_png"]), mimetype="image/png", as_attachment=True,
                     download_name="stego.png")


@app.route("/download_stego_key")
def download_stego_key():
    if STATE["stego_keyfile"] is None:
        return "Žiadny .key súbor (nebol vytvorený)", 404
    return send_file(io.BytesIO(STATE["stego_keyfile"]), mimetype="application/octet-stream",
                     as_attachment=True, download_name="stego_key.key")


@app.route("/preview_stego_secret")
def preview_stego_secret():
    if STATE["stego_out"] is None:
        return "No data", 404
    return _send_opened(STATE["stego_out"], inline=True)


@app.route("/download_stego_secret")
def download_stego_secret():
    if STATE["stego_out"] is None:
        return "Žiadny súbor", 404
    return _send_opened(STATE["stego_out"], inline=False)


# ---- TEXT ----
@app.route("/text_encrypt", methods=["POST"])
def text_encrypt_route():
    global _encrypted_text, _original_text_length, _encrypted_text_length, _decrypted_text
    _decrypted_text = None
    plain_text = request.form.get("plain_text", "").strip()
    try:
        key_clean = core.require_valid_key(request.form.get("key", ""))
        if not plain_text:
            raise core.TitanError("EMPTY", "Zadaj text.")
        encrypted_text = core.text_encrypt(plain_text, key_clean)
        _encrypted_text = encrypted_text
        _original_text_length = len(plain_text)
        _encrypted_text_length = len(encrypted_text)
        save_text_history(encrypted_text)
        return render_template_string(INDEX_HTML, encrypted_text=encrypted_text,
                                      original_length=_original_text_length,
                                      encrypted_length=_encrypted_text_length, app_version=APP_VERSION)
    except Exception as e:
        # json.dumps bezpečne escapuje úvodzovky/</script> -> žiadny reflected XSS
        return f"<script>alert({json.dumps('Chyba: ' + err_text(e))}); window.history.back();</script>"


@app.route("/text_decrypt", methods=["POST"])
def text_decrypt_route():
    global _decrypted_text, _encrypted_text
    _encrypted_text = None
    encrypted_text = request.form.get("encrypted_text", "").strip()
    try:
        key_clean = core.require_valid_key(request.form.get("key", ""))
        decrypted_text = core.text_decrypt(encrypted_text, key_clean)
        _decrypted_text = decrypted_text
        return render_template_string(INDEX_HTML, decrypted_text=decrypted_text, app_version=APP_VERSION)
    except Exception as e:
        return f"<script>alert({json.dumps('Chyba: ' + err_text(e))}); window.history.back();</script>"


@app.route("/history/list")
def history_list():
    if not HISTORY_ROOT.exists(): return jsonify({"folders": []})
    result = []
    for top_dir in ["TextCrypt", "ImgCrypt"]:
        top_path = HISTORY_ROOT / top_dir
        if top_path.is_dir():
            for item in top_path.iterdir():
                if item.is_dir() and item.name.startswith("Encrypted_"):
                    try:
                        dt = datetime.fromtimestamp(item.stat().st_ctime).strftime("%Y-%m-%d %H:%M:%S")
                        result.append({
                            "path": str(item.relative_to(HISTORY_ROOT)).replace("\\", "/"),
                            "name": item.name, "created": dt
                        })
                    except: continue
    result.sort(key=lambda x: x["created"], reverse=True)
    return jsonify({"folders": result})

@app.route("/history/delete/<path:rel_path>", methods=["POST"])
def history_delete(rel_path):
    # PÔVODNÝ KÓD tu mal path traversal: "../../../ľubovoľný/priečinok" by sa dal
    # zmazať cez shutil.rmtree, keďže rel_path sa nikde neoveroval. Teraz striktne
    # vyžadujeme presne tvar "TextCrypt/Encrypted_..." alebo "ImgCrypt/Encrypted_...",
    # a navyše overíme, že výsledná cesta reálne leží pod HISTORY_ROOT.
    if not re.fullmatch(r"(TextCrypt|ImgCrypt)/Encrypted_[0-9A-Za-z_]+", rel_path):
        return jsonify({"error": "Neplatná cesta"}), 400
    try:
        history_root_resolved = HISTORY_ROOT.resolve()
        full_path = (HISTORY_ROOT / rel_path).resolve()
        if history_root_resolved not in full_path.parents:
            return jsonify({"error": "Neplatná cesta"}), 400
        if full_path.is_dir():
            shutil.rmtree(full_path)
            return jsonify({"status": "ok"})
        return jsonify({"error": "Nie je priečinok"}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# === HTML === (100% self-contained — žiadne externé zdroje)
INDEX_HTML = """
<!doctype html>
<html lang="sk">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Titan Crypt</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", "Helvetica Neue", Arial, sans-serif;
      background: #0f1220;
      color: #eaf0ff;
      padding: 20px;
      margin: 0;
    }
    .card {
      background: #151823;
      padding: 18px;
      border-radius: 12px;
      border: 1px solid #2b3440;
      max-width: 900px;
      margin: 0 auto 20px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    }
    label {
      display: block;
      margin-top: 14px;
      color: #aab6d1;
      font-weight: 500;
    }
    input[type=text], textarea, input[type=file] {
      width: 100%;
      padding: 10px;
      border-radius: 8px;
      background: #0e1117;
      border: 1px solid #26303b;
      color: #eaf0ff;
      font-size: 14px;
    }
    textarea {
      min-height: 120px;
      resize: vertical;
    }
    .row { display: flex; gap: 10px; margin-top: 12px; align-items: end; }
    .row > * { flex: 1; }
    button {
      padding: 10px 16px;
      border-radius: 8px;
      border: none;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s;
    }
    .small { padding: 8px 12px; font-size: 0.9rem; }
    .note { font-size: 0.9rem; color: #97a6c2; margin-top: 8px; }
    .img-preview-container {
      margin-top: 12px;
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      gap: 10px;
    }
    .img-preview {
      max-width: 100%;
      display: block;
      border: 1px solid #26303b;
      border-radius: 8px;
      background: #0b0e17;
    }
    .img-actions { display: flex; flex-wrap: wrap; gap: 10px; align-items: center; }
    #history-panel + .card { margin-top: 14px; padding-top: 18px; border-top: 1px solid #2b3440; }
    .dice-btn {
      background: #2b3140;
      padding: 10px;
      border-radius: 8px;
      cursor: pointer;
      font-size: 1.3rem;
      display: flex;
      align-items: center;
      justify-content: center;
      width: 46px;
      height: 46px;
      flex-shrink: 0;
    }
    .key-input-container {
      display: flex;
      gap: 10px;
      align-items: center;
      flex-wrap: wrap;
    }
    .error-message {
      color: #ff6b6b;
      font-size: 0.85rem;
      margin-top: 6px;
      display: none;
      align-items: center;
      gap: 6px;
    }
    .section { margin-top: 28px; border-top: 1px solid #28313e; padding-top: 28px; }
    .copy-text-btn {
      background: #2b3140;
      padding: 8px 14px;
      border-radius: 6px;
      cursor: pointer;
      font-size: 0.95rem;
      margin-top: 10px;
      display: inline-flex;
      align-items: center;
      gap: 6px;
    }
    .download-btn {
      background: #2e8b57 !important;
      color: white;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .stop-btn {
      background: #d32f2f !important;
      color: white;
      padding: 8px 14px !important;
      margin-top: 10px;
    }
    .speed-radio {
      display: flex;
      gap: 16px;
      margin-top: 10px;
      font-size: 0.95rem;
      color: #aab6d1;
    }
    .speed-radio label {
      display: flex;
      align-items: center;
      gap: 6px;
      cursor: pointer;
    }
    .progress-container {
      margin-top: 14px;
      display: none;
    }
    .progress-bar {
      height: 24px;
      background: #2b3440;
      border-radius: 6px;
      overflow: hidden;
    }
    .progress-fill {
      height: 100%;
      width: 0%;
      background: #2e8b57;
      transition: width 0.3s;
    }
    .progress-status {
      font-size: 0.9rem;
      color: #aab6d1;
      margin-top: 6px;
    }

    /* HISTORY */
    .history-item {
      background: #1a1e2b;
      padding: 12px;
      border-radius: 8px;
      margin-bottom: 10px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-left: 4px solid #2e8b57;
    }
    .history-item-text { border-left-color: #8b5cf6; }
    .history-item-name {
      font-weight: 600;
      color: #eaf0ff;
      font-size: 1.05rem;
    }
    .history-item-time {
      font-size: 0.85rem;
      color: #97a6c2;
    }
    .delete-btn {
      background: #d32f2f;
      color: white;
      border: none;
      border-radius: 6px;
      width: 32px;
      height: 32px;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      font-size: 0.95rem;
      flex-shrink: 0;
    }

    /* Hlavný nadpis */
    h2 {
      color: #2e8b57;
      text-align: center;
      margin: 0 0 16px;
      font-weight: 700;
    }
  </style>
</head>
<body>

<!-- Hlavička: logo, nadpis hneď vpravo od loga, História vpravo (jeden riadok, zarovnané s kartami) -->
<div style="max-width: 938px; margin: 0 auto 14px; display: flex; align-items: center; gap: 18px; flex-wrap: wrap;">
  <img src="static/TitanCryptLogo2.png"
      alt="Titan Crypt Logo"
      width="128"
      height="128"
      style="border-radius: 10px; border: 2px solid #ff0000; flex-shrink: 0;">
  <div style="font-size: 1.8rem; font-weight: bold; color: #eaf0ff;">Titan Crypt</div>
  <button id="history-toggle" style="
    margin-left: auto;
    background: #2b3440; border: none; color: #aab6d1; padding: 8px 16px;
    border-radius: 8px; cursor: pointer; font-size: 1rem; font-weight: 500;
  ">☰ História</button>
</div>

<div id="history-panel" class="card" style="display: none;">
  <h3 style="margin-top: 0; color: #aab6d1;">História šifrovania</h3>
  <div id="history-content" style="margin-top: 14px;">
    <p style="color: #97a6c2;">Načítavam...</p>
  </div>
</div>

<div class="card section">
  <h2>ImgCrypt</h2>
  <h3>1) Šifrovanie obrázka → súbory</h3>
  <div id="encrypt-section">
    <label>Vyber obrázok (alebo ľubovoľný súbor):</label>
    <input type="file" id="encrypt-image">

    <label>Kľúč (A–Z, 0–9; presne 25 znakov):</label>
    <div class="key-input-container">
      <input type="text" id="encrypt-key" placeholder="Napr. ABC12..." maxlength="29" style="flex: 1; min-width: 250px;">
      <button type="button" class="dice-btn" onclick="generateRandomKey()">🎲</button>
      <button class="copy-btn" type="button" onclick="copyEncryptionKey()" style="padding: 8px 12px; background: #2b3140;">📋 Kopírovať</button>
      <button class="small" type="button" onclick="startEncrypt()" id="encrypt-submit-btn" disabled>Zašifrovať</button>
    </div>

    <div class="error-message" id="key-error">
      <span>!</span>
      <span>Kľúč musí obsahovať presne 25 znakov (A-Z, 0-9)</span>
    </div>
    <div style="color:red; font-size: 20px;" class="note"><center>!! SKOPÍRUJ KĽÚČ - potrebný pre dešifrovanie !!<center></div>
    <div class="note">Pomlčky sa automaticky vkladajú každých 5 znakov.</div>

    <label style="display:flex; gap:8px; align-items:center; margin-top:14px;">
      <input type="checkbox" id="encrypt-use-keyfile" style="width:auto;">
      Vytvoriť aj .key súbor (2. faktor: dešifrovanie bude vyžadovať kľúč AJ .key)
    </label>
    <div class="note">Bez zaškrtnutia vznikne JEDEN súbor (.tcrypt) – najjednoduchšie a najbezpečnejšie na posielanie.</div>
    
    <label>Režim spracovania (RAM optimalizácia):</label>
    <div class="speed-radio">
      <label><input type="radio" name="speed_mode" value="high"> High</label>
      <label><input type="radio" name="speed_mode" value="medium" checked> Medium</label>
      <label><input type="radio" name="speed_mode" value="slow"> Slow</label>
      <label><input type="radio" name="speed_mode" value="veryslow"> Very slow</label>
    </div>

    <div class="progress-container" id="encrypt-progress">
      <div class="progress-bar"><div class="progress-fill" id="encrypt-bar"></div></div>
      <div class="progress-status" id="encrypt-status">0% (odhad: --s)</div>
      <button class="small stop-btn" id="encrypt-stop-btn" onclick="cancelEncryptTask()">⏹ Zrušiť</button>
    </div>
  </div>

  <hr style="margin: 20px 0; border-color: #28313e;">

  <h3>2) Dešifrovanie súborov → obrázok</h3>
  <div id="decrypt-section">
    <label>Nahraj zašifrovaný súbor (.tcrypt, alebo starý .png):</label>
    <input type="file" id="decrypt-image-file" accept=".tcrypt,.png">
    <label>Nahraj .key súbor (len ak bol pri šifrovaní vytvorený):</label>
    <input type="file" id="decrypt-key-file" accept=".key">

    <label>Kľúč (A–Z, 0–9; presne 25 znakov):</label>
    <div class="key-input-container">
      <input type="text" id="decrypt-key" placeholder="Vlož kľúč pre dešifrovanie" maxlength="29" style="flex: 1; min-width: 220px;">
      <button class="copy-btn" type="button" onclick="copyDecryptionKey()" style="padding: 8px 12px; background: #2b3140;">📋 Kopírovať</button>
      <button class="small" type="button" onclick="startDecrypt()" id="decrypt-submit-btn" disabled>Dešifrovať</button>
    </div>

    <div class="error-message" id="decrypt-key-error">
      <span>!</span>
      <span>Kľúč musí obsahovať presne 25 znakov (A-Z, 0-9)</span>
    </div>

    <label>Režim spracovania:</label>
    <div class="speed-radio">
      <label><input type="radio" name="decrypt_speed_mode" value="high"> High</label>
      <label><input type="radio" name="decrypt_speed_mode" value="medium" checked> Medium</label>
      <label><input type="radio" name="decrypt_speed_mode" value="slow"> Slow</label>
      <label><input type="radio" name="decrypt_speed_mode" value="veryslow"> Very slow</label>
    </div>

    <div class="progress-container" id="decrypt-progress">
      <div class="progress-bar"><div class="progress-fill" id="decrypt-bar"></div></div>
      <div class="progress-status" id="decrypt-status">0% (odhad: --s)</div>
      <button class="small stop-btn" id="decrypt-stop-btn" onclick="cancelDecryptTask()">⏹ Zrušiť</button>
    </div>
  </div>

  {% if enc_success %}
    <hr id="result-anchor">
    <h3 style="color: #2e8b57;">Šifrovanie úspešné! ✅</h3>
    <div style="margin-top:14px; display:flex; flex-wrap:wrap; gap:12px;">
      <a href="/download_encrypted_image" style="text-decoration:none;">
        <button class="small download-btn">⬇️ Zašifrovaný súbor (.tcrypt)</button>
      </a>
      {% if enc_has_key %}
      <a href="/download_decryption_key" style="text-decoration:none;">
        <button class="small download-btn">⬇️ .key súbor</button>
      </a>
      {% endif %}
    </div>
    <div class="note" style="margin-top:10px; background: #2b1a1a; padding: 10px; border-radius: 6px;">
      🔒 <strong>Pošli súbor ako „súbor/dokument“ (nie ako fotku) alebo v ZIP-e.</strong>
      <div style="margin-top:6px; color:#97a6c2;">Odtlačok súboru: <code>{{ enc_info }}</code> – ak kamarátovi dešifrovanie hlási problém, porovnajte si ho.</div>
      {% if enc_has_key %}Odošli aj .key – bez neho sa súbor neotvorí.{% else %}Netreba nič ďalšie okrem kľúča.{% endif %}
    </div>
  {% endif %}

  {% if dec_ready %}
    <hr id="result-anchor">
    <h3>Dešifrovaný výsledok</h3>
    {% if dec_legacy %}<div class="note">Súbor bol v starom formáte (v1) – pri ďalšom šifrovaní sa použije nový TC2.</div>{% endif %}
    {% if dec_is_text %}
      <textarea readonly>{{ dec_text }}</textarea>
    {% elif dec_is_image %}
      <div class="img-preview-container">
        <img src="/preview_decrypted" class="img-preview" alt="Dešifrovaný obrázok">
        <div class="img-actions">
          <a href="/download_decrypted" style="text-decoration:none;"><button class="small download-btn">⬇️ Stiahnuť</button></a>
          <a href="/preview_decrypted" target="_blank" rel="noopener" style="color:#8fb4ff; font-size:0.9rem;">Otvoriť v plnej veľkosti</a>
        </div>
      </div>
    {% else %}
      <a href="/download_decrypted" style="text-decoration:none;">
        <button class="small download-btn">⬇️ Stiahnuť {{ dec_filename }}</button>
      </a>
    {% endif %}
  {% endif %}
</div>

<div class="card section">
  <h2>StegoCrypt</h2>
  <h3>1) Ukryť dáta do PNG obrázka</h3>
  <label>Krycí obrázok (výstup je vždy PNG):</label>
  <input type="file" id="stego-cover" accept="image/*">

  <label>Tajný text:</label>
  <textarea id="stego-text" placeholder="Tajný text… (alebo vyber súbor nižšie; ak vyberieš súbor, použije sa súbor)"></textarea>
  <label>…alebo tajný súbor:</label>
  <input type="file" id="stego-file">

  <label>Kľúč (A–Z, 0–9; presne 25 znakov):</label>
  <div class="key-input-container">
    <input type="text" id="stego-key" placeholder="Napr. ABC12..." maxlength="29" style="flex: 1; min-width: 250px;">
    <button type="button" class="dice-btn" onclick="generateStegoKey('stego-key')">🎲</button>
    <button class="copy-btn" type="button" onclick="copyField('stego-key')" style="padding: 8px 12px; background: #2b3140;">📋 Kopírovať</button>
    <button class="small" type="button" onclick="startStegoHide()">Ukryť</button>
  </div>
  <div class="error-message" id="stego-key-error">
    <span>!</span><span>Kľúč musí obsahovať presne 25 znakov (A-Z, 0-9)</span>
  </div>
  <label style="display:flex; gap:8px; align-items:center; margin-top:14px;">
    <input type="checkbox" id="stego-use-keyfile" style="width:auto;"> Vytvoriť aj .key súbor (2. faktor)
  </label>
  <div class="note" style="background:#2b1a1a; padding:10px; border-radius:6px;">
    ⚠️ Výsledné PNG posielaj ako <strong>súbor/dokument</strong>. Messenger, Instagram, WhatsApp („fotka“),
    zmenšenie alebo uloženie ako JPEG ukryté dáta nenávratne zničia.
  </div>
  <div class="note" id="stego-hide-status"></div>

  {% if stego_hide_ok %}
    <h3 id="result-anchor" style="color: #2e8b57;">Ukrytie úspešné ✅</h3>
    <div style="margin-top:14px; display:flex; flex-wrap:wrap; gap:12px;">
      <a href="/download_stego" style="text-decoration:none;"><button class="small download-btn">⬇️ Obrázok s dátami (.png)</button></a>
      {% if stego_has_key %}
      <a href="/download_stego_key" style="text-decoration:none;"><button class="small download-btn">⬇️ .key súbor</button></a>
      {% endif %}
    </div>
  {% endif %}

  <hr style="margin: 20px 0; border-color: #28313e;">

  <h3>2) Vytiahnuť dáta z obrázka</h3>
  <label>Obrázok s ukrytými dátami (.png):</label>
  <input type="file" id="stego-extract-image" accept=".png,image/png">
  <label>.key súbor (len ak bol pri ukrývaní vytvorený):</label>
  <input type="file" id="stego-extract-keyfile" accept=".key">
  <label>Kľúč (A–Z, 0–9; presne 25 znakov):</label>
  <div class="key-input-container">
    <input type="text" id="stego-extract-key" placeholder="Vlož kľúč" maxlength="29" style="flex: 1; min-width: 250px;">
    <button class="small" type="button" onclick="startStegoExtract()" style="background: #8b5cf6;">Vytiahnuť</button>
  </div>
  <div class="error-message" id="stego-extract-key-error">
    <span>!</span><span>Kľúč musí obsahovať presne 25 znakov (A-Z, 0-9)</span>
  </div>
  <div class="note" id="stego-extract-status"></div>

  {% if stego_out_ready %}
    <h3 id="result-anchor">Vytiahnutý obsah</h3>
    {% if stego_out_is_text %}
      <textarea readonly>{{ stego_out_text }}</textarea>
    {% elif stego_out_is_image %}
      <div class="img-preview-container">
        <img src="/preview_stego_secret" class="img-preview" alt="Ukrytý obrázok">
        <div class="img-actions">
          <a href="/download_stego_secret" style="text-decoration:none;"><button class="small download-btn">⬇️ Stiahnuť</button></a>
          <a href="/preview_stego_secret" target="_blank" rel="noopener" style="color:#8fb4ff; font-size:0.9rem;">Otvoriť v plnej veľkosti</a>
        </div>
      </div>
    {% else %}
      <a href="/download_stego_secret" style="text-decoration:none;">
        <button class="small download-btn">⬇️ Stiahnuť {{ stego_out_filename }}</button>
      </a>
    {% endif %}
  {% endif %}
</div>

<div class="card section">
  <h2>TextCrypt</h2>

  <form method="post" action="/text_encrypt" id="textEncryptForm" style="margin-bottom:28px;">
    <label>Kľúč (A–Z, 0–9; presne 25 znakov):</label>
    <div class="key-input-container">
      <input type="text" id="text-key" name="key" placeholder="Napr. ABC12..." required maxlength="29" style="flex: 1; min-width: 250px;">
      <button type="button" class="dice-btn" onclick="generateTextRandomKey()">🎲</button>
      <button class="copy-btn" type="button" onclick="copyTextKey()" style="padding: 8px 12px; background: #2b3140;">📋 Kopírovať</button>
      <button class="small" type="submit">🔒 Zašifrovať</button>
    </div>
    <div class="error-message" id="text-key-error" style="margin-top:8px;">
      <span>!</span>
      <span>Kľúč musí obsahovať presne 25 znakov</span>
    </div>

    <label>Text na zašifrovanie (podporuje diakritiku):</label>
    <textarea id="plain-text" name="plain_text" placeholder="Zadaj text na zašifrovanie..." required></textarea>
  </form>

  {% if encrypted_text %}
    <hr id="result-anchor">
    <h3>Zašifrovaný text:</h3>
    <textarea id="encrypted-text-display" readonly>{{ encrypted_text }}</textarea>
    <button class="copy-text-btn" onclick="copyEncryptedText()">📋 Kopírovať</button>
    <div class="note" style="margin-top:8px;">
      Dĺžka: {{ original_length }} → {{ encrypted_length }} znakov
    </div>
  {% endif %}

  <hr>

  <form method="post" action="/text_decrypt" id="textDecryptForm">
    <label>Kľúč (A–Z, 0–9; presne 25 znakov):</label>
    <div class="key-input-container">
      <input type="text" id="decrypt-text-key" name="key" placeholder="Napr. ABC12..." required maxlength="29" style="flex: 1; min-width: 250px;">
      <button class="copy-btn" type="button" onclick="copyDecryptTextKey()" style="padding: 8px 12px; background: #2b3140;">📋 Kopírovať</button>
      <button class="small" type="submit" style="background: #8b5cf6;">🔓 Dešifrovať</button>
    </div>
    <div class="error-message" id="decrypt-text-key-error" style="margin-top:8px;">
      <span>!</span>
      <span>Kľúč musí obsahovať presne 25 znakov</span>
    </div>

    <label>Zašifrovaný text na dešifrovanie:</label>
    <textarea id="encrypted-text-input" name="encrypted_text" placeholder="Vlož zašifrovaný text..." required></textarea>
  </form>

  {% if decrypted_text %}
    <hr id="result-anchor">
    <h3>Dešifrovaný text:</h3>
    <textarea id="decrypted-text-display" readonly>{{ decrypted_text }}</textarea>
    <button class="copy-text-btn" onclick="copyDecryptedText()">📋 Kopírovať</button>
  {% endif %}
</div>

<script>
let currentEncryptTaskId = null;
let currentDecryptTaskId = null;

function formatKey(input) {
  let v = input.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (v.length > 25) v = v.substring(0, 25);
  input.value = v.match(/.{1,5}/g)?.join('-') || '';
}

function validateKey(input) {
  const clean = input.value.replace(/-/g, '');
  const errorId = ({'encrypt-key':'key-error','decrypt-key':'decrypt-key-error','text-key':'text-key-error',
    'decrypt-text-key':'decrypt-text-key-error','stego-key':'stego-key-error',
    'stego-extract-key':'stego-extract-key-error'})[input.id] || 'decrypt-key-error';
  const errorElement = document.getElementById(errorId);
  if (!errorElement) return;
  
  if (clean.length !== 25) {
    errorElement.style.display = 'flex';
  } else {
    errorElement.style.display = 'none';
  }
  
  // ✅ VŽDY zavolaj validáciu formulárov — nech rozhodne kombinácia súbor + kľúč
  checkEncryptFormReady();
  checkDecryptFormReady();
}

function checkEncryptFormReady() {
  const file = document.getElementById('encrypt-image').files[0];
  const key = document.getElementById('encrypt-key').value.replace(/-/g, '');
  const btn = document.getElementById('encrypt-submit-btn');
  btn.disabled = !(file && key.length === 25);
}

function checkDecryptFormReady() {
  const i = document.getElementById('decrypt-image-file').files[0];
  const key = document.getElementById('decrypt-key').value.replace(/-/g, '');
  const btn = document.getElementById('decrypt-submit-btn');
  btn.disabled = !(i && key.length === 25);
}

// Math.random() nie je kryptograficky bezpečný PRNG (predvídateľný stav) -> pre
// generovanie šifrovacích kľúčov použijeme crypto.getRandomValues().
function secureRandomKeyString(length) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  const bytes = new Uint32Array(length);
  crypto.getRandomValues(bytes);
  let r = '';
  for (let i = 0; i < length; i++) r += chars[bytes[i] % chars.length];
  return r;
}

function generateRandomKey() {
  const r = secureRandomKeyString(25);
  document.getElementById('encrypt-key').value = r.match(/.{1,5}/g).join('-');
  validateKey(document.getElementById('encrypt-key'));
}

function generateTextRandomKey() {
  const r = secureRandomKeyString(25);
  document.getElementById('text-key').value = r.match(/.{1,5}/g).join('-');
  document.getElementById('text-key').dispatchEvent(new Event('input'));
}

function copyEncryptionKey() {
  document.getElementById('encrypt-key').select();
  document.execCommand('copy');
}

function copyDecryptionKey() {
  document.getElementById('decrypt-key').select();
  document.execCommand('copy');
}

function copyTextKey() {
  document.getElementById('text-key').select();
  document.execCommand('copy');
}

function copyDecryptTextKey() {
  document.getElementById('decrypt-text-key').select();
  document.execCommand('copy');
}

function copyEncryptedText() {
  document.getElementById('encrypted-text-display').select();
  document.execCommand('copy');
}

function copyDecryptedText() {
  document.getElementById('decrypted-text-display').select();
  document.execCommand('copy');
}

async function startEncrypt() {
  const file = document.getElementById('encrypt-image').files[0];
  const key = document.getElementById('encrypt-key').value;
  const mode = document.querySelector('input[name="speed_mode"]:checked')?.value || 'medium';
  if (!file || key.replace(/-/g, '').length !== 25) return alert("Vyplň všetky polia správne!");
  const fd = new FormData();
  fd.append('image', file); fd.append('key', key); fd.append('speed_mode', mode);
  fd.append('use_keyfile', document.getElementById('encrypt-use-keyfile').checked ? '1' : '0');
  document.getElementById('encrypt-progress').style.display = 'block';
  try {
    const res = await fetch('/start_encrypt', {method:'POST', body:fd});
    const d = await res.json();
    if (d.error) throw new Error(d.error);
    currentEncryptTaskId = d.task_id;
    pollEncryptStatus(d.task_id);
  } catch (e) { alert("Chyba: " + e.message); resetEncryptUI(); }
}

function pollEncryptStatus(tid) {
  const bar = document.getElementById('encrypt-bar');
  const status = document.getElementById('encrypt-status');
  const iv = setInterval(async () => {
    try {
      const res = await fetch(`/status/${tid}`);
      const s = await res.json();
      if (s.error) { clearInterval(iv); alert("Chyba: "+s.error); resetEncryptUI(); }
      else if (s.done) { clearInterval(iv); resetEncryptUI(); window.location.search='?task=encrypt_success'; }
      else { bar.style.width = s.progress + '%'; status.textContent = `${s.progress}% (odhad: ${s.eta}s)`; }
    } catch (e) { clearInterval(iv); alert("Chyba pripojenia"); resetEncryptUI(); }
  }, 300);
}

function resetEncryptUI() {
  document.getElementById('encrypt-progress').style.display = 'none';
  currentEncryptTaskId = null;
}

function cancelEncryptTask() {
  if (currentEncryptTaskId) {
    fetch(`/cancel_task/${currentEncryptTaskId}`, {method:'POST'});
    resetEncryptUI();
    alert("Úloha bola zrušená.");
  }
}

async function startDecrypt() {
  const img = document.getElementById('decrypt-image-file').files[0];
  const keyf = document.getElementById('decrypt-key-file').files[0];   // voliteľný
  const key = document.getElementById('decrypt-key').value;
  const mode = document.querySelector('input[name="decrypt_speed_mode"]:checked')?.value || 'medium';
  if (!img || key.replace(/-/g, '').length !== 25) return alert("Vyber súbor a zadaj 25-znakový kľúč!");
  const fd = new FormData();
  fd.append('image_file', img); if (keyf) fd.append('key_file', keyf); fd.append('key', key); fd.append('speed_mode', mode);
  document.getElementById('decrypt-progress').style.display = 'block';
  try {
    const res = await fetch('/start_decrypt', {method:'POST', body:fd});
    const d = await res.json();
    if (d.error) throw new Error(d.error);
    currentDecryptTaskId = d.task_id;
    pollDecryptStatus(d.task_id);
  } catch (e) { alert("Chyba: " + e.message); resetDecryptUI(); }
}

function pollDecryptStatus(tid) {
  const bar = document.getElementById('decrypt-bar');
  const status = document.getElementById('decrypt-status');
  const iv = setInterval(async () => {
    try {
      const res = await fetch(`/status/${tid}`);
      const s = await res.json();
      if (s.error) { clearInterval(iv); alert("Chyba: "+s.error); resetDecryptUI(); }
      else if (s.done) { clearInterval(iv); resetDecryptUI(); window.location.search='?task=decrypt_success'; }
      else { bar.style.width = s.progress + '%'; status.textContent = `${s.progress}% (odhad: ${s.eta}s)`; }
    } catch (e) { clearInterval(iv); alert("Chyba pripojenia"); resetDecryptUI(); }
  }, 300);
}

function resetDecryptUI() {
  document.getElementById('decrypt-progress').style.display = 'none';
  currentDecryptTaskId = null;
}

function cancelDecryptTask() {
  if (currentDecryptTaskId) {
    fetch(`/cancel_task/${currentDecryptTaskId}`, {method:'POST'});
    resetDecryptUI();
    alert("Úloha bola zrušená.");
  }
}

// STEGO
function generateStegoKey(id) {
  const r = secureRandomKeyString(25);
  const el = document.getElementById(id);
  el.value = r.match(/.{1,5}/g).join('-');
  validateKey(el);
}

function copyField(id) {
  document.getElementById(id).select();
  document.execCommand('copy');
}

async function startStegoHide() {
  const cover = document.getElementById('stego-cover').files[0];
  const text = document.getElementById('stego-text').value;
  const sf = document.getElementById('stego-file').files[0];
  const key = document.getElementById('stego-key').value;
  const st = document.getElementById('stego-hide-status');
  if (!cover) return alert('Vyber krycí obrázok.');
  if (!text.trim() && !sf) return alert('Zadaj tajný text alebo vyber súbor.');
  if (key.replace(/-/g, '').length !== 25) return alert('Kľúč musí mať presne 25 znakov.');
  const fd = new FormData();
  fd.append('cover', cover); fd.append('key', key); fd.append('secret_text', text);
  if (sf) fd.append('secret_file', sf);
  fd.append('use_keyfile', document.getElementById('stego-use-keyfile').checked ? '1' : '0');
  st.textContent = 'Spracúvam… (môže trvať niekoľko sekúnd)';
  try {
    const res = await fetch('/stego_hide', {method:'POST', body: fd});
    const d = await res.json();
    if (d.error) throw new Error(d.error);
    window.location.search = '?task=stego_hide_success';
  } catch (e) { st.textContent = ''; alert('Chyba: ' + e.message); }
}

async function startStegoExtract() {
  const img = document.getElementById('stego-extract-image').files[0];
  const kf = document.getElementById('stego-extract-keyfile').files[0];
  const key = document.getElementById('stego-extract-key').value;
  const st = document.getElementById('stego-extract-status');
  if (!img) return alert('Vyber obrázok s ukrytými dátami.');
  if (key.replace(/-/g, '').length !== 25) return alert('Kľúč musí mať presne 25 znakov.');
  const fd = new FormData();
  fd.append('stego_image', img); fd.append('key', key);
  if (kf) fd.append('key_file', kf);
  st.textContent = 'Spracúvam… (môže trvať niekoľko sekúnd)';
  try {
    const res = await fetch('/stego_extract', {method:'POST', body: fd});
    const d = await res.json();
    if (d.error) throw new Error(d.error);
    window.location.search = '?task=stego_extract_success';
  } catch (e) { st.textContent = ''; alert('Chyba: ' + e.message); }
}

// HISTORY
document.getElementById('history-toggle').addEventListener('click', function() {
  const p = document.getElementById('history-panel');
  p.style.display = p.style.display === 'none' ? 'block' : 'none';
  if (p.style.display === 'block') loadHistory();
});

async function loadHistory() {
  const c = document.getElementById('history-content');
  try {
    const res = await fetch('/history/list');
    const d = await res.json();
    if (d.folders?.length) {
      c.innerHTML = d.folders.map(i => `
        <div class="history-item ${i.path.startsWith('TextCrypt') ? 'history-item-text' : ''}">
          <div>
            <div class="history-item-name">${i.name}</div>
            <div class="history-item-time">${i.created}</div>
          </div>
          <button class="delete-btn" onclick="deleteHistoryItem('${i.path}')">🗑️</button>
        </div>
      `).join('');
    } else c.innerHTML = '<p style="color:#97a6c2;">Žiadna história</p>';
  } catch (e) { c.innerHTML = `<p style="color:#ff6b6b;">Chyba: ${e.message}</p>`; }
}

async function deleteHistoryItem(relPath) {
  if (!confirm("Naozaj zmazať túto položku histórie?")) return;
  try {
    const res = await fetch(`/history/delete/${encodeURIComponent(relPath)}`, {method:'POST'});
    if (res.ok) loadHistory(); else alert("Chyba pri mazaní");
  } catch (e) { alert("Chyba: " + e.message); }
}

window.addEventListener('load', function() {
  const a = document.getElementById('result-anchor');
  if (a) a.scrollIntoView({block: 'start'});
});

document.addEventListener('DOMContentLoaded', function() {
  ['encrypt-key','decrypt-key','text-key','decrypt-text-key','stego-key','stego-extract-key'].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener('input', function() {
        formatKey(this);      // najskôr doplní pomlčky
        validateKey(this);    // potom validuj → zavolá check...
      });
    }
  });
  document.getElementById('encrypt-image')?.addEventListener('change', checkEncryptFormReady);
  document.getElementById('decrypt-image-file')?.addEventListener('change', checkDecryptFormReady);
  document.getElementById('decrypt-key-file')?.addEventListener('change', checkDecryptFormReady);
});
</script>
</body>
</html>
"""


# === FLASK SERVER (s korektným shutdownom) ===
def run_server(port):
    global server_instance
    print(f"[SERVER] Spúšťam na http://{HOST}:{port}")
    try:
        # Použijeme make_server pre explicitný shutdown
        server_instance = make_server(HOST, port, app, threaded=True)
        server_instance.serve_forever()
    except Exception as e:
        if not stop_event.is_set():
            print(f"[SERVER] Chyba: {e}")
    finally:
        try:
            if server_instance is not None:
                server_instance.server_close()      # uvoľní port
        except Exception:
            pass


# === GUI ===
class ServerGUI:
    def __init__(self):
        self.root = tk.Tk()
        
        try:
            self.root.iconbitmap(str(STATIC_DIR / "TitanCryptLogo2.ico"))
        except Exception as icon_err:      # predtým: "..." + Exception -> TypeError -> pád appky
            print(f"Nepodarilo sa načítať ikonu pre GUI! CHYBA: {icon_err}")

        self.root.title("Titan Crypt - your hiding software")
        self.root.geometry("560x260")
        self.root.configure(bg="#0d0f1a")
        self.root.resizable(False, False)
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)

        # Centruj okno
        self.root.update_idletasks()
        x = (self.root.winfo_screenwidth() // 2) - (560 // 2)
        y = (self.root.winfo_screenheight() // 2) - (260 // 2)
        self.root.geometry(f"560x260+{x}+{y}")

        # === LOGO (naľavo) ===
        logo_frame = tk.Frame(self.root, bg="#0d0f1a")
        logo_frame.pack(side="left", padx=(70,0), pady=10)

        self.logo_photo = None

        try:
            # Použi PIL s unikátnymi menami (bez kolízií s tkinter.font)
            from PIL import Image as PILImage, ImageTk, ImageDraw, ImageFont as PILFont
            logo_path = STATIC_DIR / "TitanCryptLogo2.png"
            if logo_path.exists():
                img = PILImage.open(logo_path).convert("RGBA")
                img = img.resize((128, 128), PILImage.LANCZOS)
                # Vytvor obrázok s border-radius a borderom
                bordered = PILImage.new("RGBA", (132, 132), (0, 0, 0, 0))

                bordered.paste(img, (2, 2))
                # Pridaj červený border
                draw = ImageDraw.Draw(bordered)
                draw.rounded_rectangle((0, 0, 131, 131), radius=10, outline=(255,0,0), width=2)
                self.logo_photo = ImageTk.PhotoImage(bordered)
            else:
                raise FileNotFoundError("Logo neexistuje")
        except Exception as e:
            print(f"[GUI] PNG logo sa nepodarilo načítať: {e}")
            # Fallback: vytvor logo programovo
            try:
                from PIL import Image as PILImage, ImageTk, ImageDraw
                img = PILImage.new("RGBA", (128, 128), (13, 15, 26, 255))
                draw = ImageDraw.Draw(img)
                draw.rectangle((8, 8, 120, 120), outline=(255, 0, 0), width=4)
                # Použi bezpečný font (ak arial nie je, použi default)
                try:
                    fallback_font = PILImage.ImageFont.truetype("arialbd.ttf", 64)
                except:
                    fallback_font = None
                draw.text((64, 36), "T", fill=(255, 0, 0), font=fallback_font, anchor="mm")
                self.logo_photo = ImageTk.PhotoImage(img)
            except Exception as e2:
                print(f"[GUI] Fallback logo zlyhalo: {e2}")
                self.logo_photo = None

        if self.logo_photo:
            logo_label = tk.Label(logo_frame, image=self.logo_photo, bg="#0d0f1a")
            logo_label.pack()

        # === HLAVNÝ OBSAH (napravo od loga) ===
        content_frame = tk.Frame(self.root, bg="#0d0f1a")
        content_frame.pack(side="left", fill="both", expand=True, padx=(0, 20))

        # 🟢 TU JE DÔLEŽITÉ: `font` je z tkinteru, nie z PIL!
        # Ak si ho importoval ako `from tkinter import ..., font`, tak je to OK
        title_font = font.Font(family="Segoe UI", size=16, weight="bold")
        label_font = font.Font(family="Segoe UI", size=11)

        tk.Label(
            content_frame,
            text="🛡️Titan Crypt Server",
            font=title_font,
            fg="#2e8b57",
            bg="#0d0f1a"
        ).pack(pady=(20, 5))

        self.status_label = tk.Label(
            content_frame,
            text="Server je zastavený",
            font=("Segoe UI", 11, "bold"),
            fg="#d32f2f",
            bg="#0d0f1a"
        )
        self.status_label.pack()

        self.port_label = tk.Label(
            content_frame,
            text="Port: —",
            font=("Segoe UI", 10),
            fg="#999999",
            bg="#0d0f1a"
        )
        self.port_label.pack()

        self.btn = tk.Button(
            content_frame,
            text="▶️ Spustiť server",
            command=self.toggle_server,
            bg="#2e8b57",
            fg="white",
            font=("Segoe UI", 11, "bold"),
            width=20,
            height=2,
            relief="flat",
            bd=0,
            activebackground="#257a4a",
            activeforeground="white"
        )
        self.btn.pack(pady=5)


        tk.Label(
            content_frame,
            text=f"Verzia: {APP_VERSION} (formát {core.FORMAT_NAME})",
            font=("Segoe UI", 9),
            fg="#777777",
            bg="#0d0f1a"
        ).pack(side="top", pady=(0,5))

        tk.Label(
            content_frame,
            text="Stav aktualizácii: Nedostupné ❌",
            font=("Segoe UI", 9),
            fg="#777777",
            bg="#0d0f1a"
        ).pack(side="top", pady=(0,5))

        tk.Label(
            content_frame,
            text="Po spustení sa automaticky otvorí webový prehliadač",
            font=("Segoe UI", 9),
            fg="#777777",
            bg="#0d0f1a"
        ).pack(side="bottom", pady=(0,5))
        self.server_running = False






    def toggle_server(self):
        if not self.server_running:
            self.start_server()
        else:
            self.stop_server()

    def start_server(self):
        global server_thread
        if server_thread and server_thread.is_alive():
            return

        # Nájdi voľný port
        try:
            port = find_free_port(DEFAULT_PORT, MAX_PORT_ATTEMPTS)
        except RuntimeError as e:
            messagebox.showerror("Chyba", str(e))
            return

        # Spusti server v novom vlákne
        stop_event.clear()
        server_thread = threading.Thread(target=run_server, args=(port,), daemon=True)
        server_thread.start()

        # Aktualizuj GUI
        self.status_label.config(text="Spúšťam server...", fg="#ff9800")
        self.port_label.config(text=f"Port: {port}")
        self.btn.config(state="disabled")

        # Počkaj a otvor prehliadač
        def delayed_open():
            time.sleep(1.2)
            if server_thread.is_alive():
                self.root.after(0, lambda: self.on_server_ready(port))

        threading.Thread(target=delayed_open, daemon=True).start()

    def on_server_ready(self, port):
        self.server_running = True
        self.status_label.config(text="✅ Server beží", fg="#2e8b57")
        self.port_label.config(text=f"Port: {port}")
        self.btn.config(
            text="⏹️ Zastaviť server",
            bg="#d32f2f",
            activebackground="#b71c1c",
            state="normal"
        )
        webbrowser.open(f"http://{HOST}:{port}")

    def stop_server(self):
        global server_instance, server_thread
        self.status_label.config(text="Zastavujem server...", fg="#ff9800")
        self.btn.config(state="disabled")

        # 1. Skutočné zastavenie: Werkzeug od v2.1 nemá request.environ['werkzeug.server.shutdown'],
        #    pôvodný POST /shutdown preto tichо zlyhával a server bežal ďalej (obsadený port).
        try:
            if server_instance is not None:
                server_instance.shutdown()
        except Exception as e:
            print(f"[GUI] Zastavenie servera zlyhalo: {e}")

        # 2. Počkaj max 2 sekundy na ukončenie vlákna
        if server_thread and server_thread.is_alive():
            server_thread.join(timeout=2.0)

        # 3. ✅ KľÚČOVÉ: zruš referencie → umožni nové spustenie
        server_instance = None
        server_thread = None
        stop_event.set()  # uvoľni aj úlohy v progrese

        # 4. Aktualizuj GUI
        self.server_running = False
        self.status_label.config(text="Server zastavený", fg="#d32f2f")
        self.port_label.config(text="Port: —")
        self.btn.config(
            text="▶️ Spustiť server",
            bg="#2e8b57",
            activebackground="#257a4a",
            state="normal"
        )

    def on_closing(self):
        if self.server_running:
            if not messagebox.askyesno("Ukončiť?", "Server práve beží.\nNaozaj to chceš ukončiť?"):
                return
        self.stop_server()
        self.root.after(300, self.root.destroy)

    def run(self):
        self.root.mainloop()


# === HLAVNÝ SPUSTNÍK ===
if __name__ == "__main__":
    if USE_GUI:
        # Zabezpečíme, že priečinok existuje
        ensure_history_dirs()
        gui = ServerGUI()
        gui.run()
    else:
        # Vývojársky režim
        port = find_free_port(DEFAULT_PORT, MAX_PORT_ATTEMPTS)
        print(f"[DEV] Spúšťam priamo na http://{HOST}:{port}")
        # POZOR: debug=True bolo v pôvodnom kóde zapnuté aj mimo vývoja - Werkzeug
        # debugger v tomto móde umožňuje vzdialené spustenie ľubovoľného Python kódu
        # (RCE), ak sa niekto dostane na endpoint s neošetrenou výnimkou. Necháme
        # vypnuté; zapni len ručne a lokálne, ak naozaj ladíš appku.
        app.run(host=HOST, port=port, debug=False)
